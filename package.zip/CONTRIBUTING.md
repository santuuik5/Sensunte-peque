# 🤝 Guía de Contribución - Sensuntepeque Cultural

¡Gracias por tu interés en contribuir al proyecto Sensuntepeque Cultural! Este proyecto está dedicado a preservar y promover la rica cultura, historia y tradiciones de Sensuntepeque, "La Ciudad de los 400 Cerros" en Cabañas, El Salvador.

## 🎆 Sobre el Proyecto

Sensuntepeque Cultural es una aplicación web que tiene como objetivo:

- 📜 Preservar la historia precolombina y colonial de Sensuntepeque
- 🎭 Documentar tradiciones únicas como "Los Fogones" y "Las Recordadas"
- 🍽️ Promover la gastronomía local, incluyendo las famosas riguas con leche cruda
- 🎪 Difundir eventos y festivales, especialmente las fiestas patronales de Santa Bárbara
- 🏔️ Mostrar los lugares emblemáticos y miradores de los "400 cerros"

## 👥 Tipos de Contribuciones

Valoraremos cualquier tipo de contribución:

### 📝 Contenido Cultural
- **Historia**: Artículos sobre eventos históricos de Sensuntepeque
- **Tradiciones**: Documentación de costumbres y celebraciones locales
- **Gastronomía**: Recetas tradicionales y platos típicos
- **Lugares**: Información sobre sitios de interés turístico
- **Eventos**: Calendario de festivales y celebraciones

### 📸 Contenido Visual
- Fotografías de paisajes, arquitectura y eventos
- Imágenes de platos típicos y preparación
- Documentación visual de tradiciones
- Mapas y diagramas ilustrativos

### 💻 Código y Desarrollo
- Mejoras en el frontend (React/TypeScript)
- Optimizaciones en el backend (Node.js/Express)
- Nuevas funcionalidades
- Corrección de bugs
- Mejoras en la documentación técnica

### 🌍 Traducciones
- Traducción del contenido al inglés
- Revisión de textos en español
- Adaptación cultural del contenido

## 🚀 Cómo Empezar

### 1. Configuración del Entorno

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/sensuntepeque-cultural.git
cd sensuntepeque-cultural

# Ejecutar script de setup
chmod +x scripts/setup.sh
./scripts/setup.sh

# Iniciar en modo desarrollo
npm run dev
```

### 2. Estructura del Proyecto

```
sensuntepeque-cultural/
├── backend/          # API REST con Node.js + Express
├── frontend/         # Aplicación React + TypeScript
├── scripts/          # Scripts de utilidad
├── docs/             # Documentación
└── docker-compose.yml # Configuración de contenedores
```

### 3. Tecnologías Utilizadas

**Frontend:**
- React 18 + TypeScript
- Tailwind CSS
- Framer Motion
- React Query
- React Router

**Backend:**
- Node.js + Express
- TypeScript
- Prisma ORM
- PostgreSQL
- Redis (cache)
- JWT (autenticación)

## 📜 Guías de Contribución

### Para Contenido Cultural

1. **Investigación**: Asegúrate de que la información sea precisa y esté bien documentada
2. **Fuentes**: Incluye fuentes confiables y referencias históricas
3. **Respeto Cultural**: Trata las tradiciones con respeto y autenticidad
4. **Idioma**: Usa un español claro y accesible
5. **Formato**: Utiliza Markdown para la estructura del contenido

### Para Código

1. **Estilo de Código**: Seguir las configuraciones de ESLint y Prettier
2. **TypeScript**: Usar tipado fuerte en todo el código
3. **Componentes**: Crear componentes reutilizables y bien documentados
4. **Testing**: Incluir pruebas para nuevas funcionalidades
5. **Documentación**: Documentar funciones y componentes complejos

### Ejemplo de Commit

```bash
# Formato recomendado
git commit -m "feat(gastronomia): agregar receta de riguas tradicionales"
git commit -m "fix(lugares): corregir coordenadas de la iglesia Santa Bárbara"
git commit -m "docs(tradiciones): actualizar documentación de Los Fogones"
```

## 📄 Proceso de Contribución

### 1. Fork y Branch

```bash
# Hacer fork del repositorio en GitHub
# Clonar tu fork
git clone https://github.com/tu-usuario/sensuntepeque-cultural.git

# Crear una nueva rama
git checkout -b feature/nueva-funcionalidad
# o
git checkout -b content/nueva-tradicion
```

### 2. Desarrollo

- Realizar los cambios necesarios
- Probar localmente
- Asegurarse de que el código sigue los estándares
- Escribir o actualizar documentación si es necesario

### 3. Pull Request

1. **Descripción Clara**: Explica qué cambios hiciste y por qué
2. **Screenshots**: Incluye capturas de pantalla si hay cambios visuales
3. **Testing**: Describe cómo probaste los cambios
4. **Referencias**: Menciona issues relacionados

### Template de Pull Request

```markdown
## 📝 Descripción
Breve descripción de los cambios realizados.

## 💸 Tipo de Cambio
- [ ] 🐛 Corrección de bug
- [ ] ✨ Nueva funcionalidad
- [ ] 📝 Contenido cultural
- [ ] 📚 Documentación
- [ ] 🎨 Mejora de UI/UX

## 🧪 Testing
- [ ] He probado los cambios localmente
- [ ] Los tests existentes pasan
- [ ] He añadido nuevos tests si es necesario

## 📸 Screenshots
(Si aplica)

## 📅 Checklist
- [ ] Mi código sigue las guías de estilo del proyecto
- [ ] He realizado una auto-revisión de mi código
- [ ] He comentado mi código donde es necesario
- [ ] He actualizado la documentación correspondiente
```

## 📚 Recursos Útiles

### Documentación de Sensuntepeque
- [Historia Oficial](https://es.wikipedia.org/wiki/Sensuntepeque)
- [Tradiciones Locales](https://masalladelos400cerros.wordpress.com/)
- [Información Turística](https://enciclotek.net/sensuntepeque-pueblo-milenario-en-el-salvador/)

### Guías Técnicas
- [React Documentation](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Prisma Documentation](https://www.prisma.io/docs/)

## 📞 Contacto y Soporte

- **Issues**: Para reportar bugs o solicitar funcionalidades
- **Discussions**: Para preguntas generales y discusiones
- **Email**: [email del proyecto]

## 🎆 Reconocimientos

Todas las contribuciones serán reconocidas en nuestro archivo de CONTRIBUTORS.md. ¡Ayudar a preservar la cultura sensuntepecana es una labor valiosa!

### Contribuidores Destacados

- **Investigación Histórica**: [Nombres de contribuidores]
- **Desarrollo Técnico**: [Nombres de contribuidores]
- **Contenido Cultural**: [Nombres de contribuidores]
- **Traducciones**: [Nombres de contribuidores]

## 📜 Licencia

Al contribuir, aceptas que tus contribuciones serán licenciadas bajo la [MIT License](LICENSE).

---

¡Gracias por ayudar a preservar y promover la hermosa cultura de Sensuntepeque! 🎆

*"Más allá de los 400 cerros, nuestra cultura trasciende"*