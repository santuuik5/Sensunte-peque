# 🚀 Guía de Despliegue - Sensuntepeque Cultural

Esta guía proporciona instrucciones detalladas para desplegar la aplicación **Sensuntepeque Cultural** en diferentes entornos de producción.

## 📋 Prerrequisitos

### Requisitos del Sistema
- **Docker** 20.10+ y **Docker Compose** 2.0+
- **Node.js** 18+ (para desarrollo local)
- **PostgreSQL** 13+ (si no usas Docker)
- **Redis** 6+ (para cache y sesiones)
- **Nginx** (para proxy reverso en producción)

### Dominios y DNS
- Dominio principal: `sensuntepeque.com`
- API: `api.sensuntepeque.com`
- Administración: `admin.sensuntepeque.com` (opcional)

## 🏗️ Opciones de Despliegue

### 1. Despliegue con Docker (Recomendado)

#### 1.1 Configuración de Variables de Entorno

Crear archivo `.env` en la raíz del proyecto:

```bash
# Configuración de Base de Datos
POSTGRES_USER=sensuntepeque_user
POSTGRES_PASSWORD=tu_password_seguro_aqui
POSTGRES_DB=sensuntepeque_db

# JWT y Seguridad
JWT_SECRET=tu_jwt_secret_muy_seguro_de_32_caracteres_o_mas

# Email para certificados SSL
ACME_EMAIL=admin@sensuntepeque.com

# URLs de producción
FRONTEND_URL=https://sensuntepeque.com
BACKEND_URL=https://api.sensuntepeque.com

# Configuración SMTP (opcional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@sensuntepeque.com
SMTP_PASS=tu_password_smtp

# Cloudinary (para imágenes)
CLOUDINARY_CLOUD_NAME=tu_cloud_name
CLOUDINARY_API_KEY=tu_api_key
CLOUDINARY_API_SECRET=tu_api_secret
```

#### 1.2 Despliegue con Docker Compose

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/sensuntepeque-cultural.git
cd sensuntepeque-cultural

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus valores

# Construir y levantar servicios
docker-compose -f docker-compose.prod.yml up -d

# Verificar estado de servicios
docker-compose -f docker-compose.prod.yml ps

# Ver logs
docker-compose -f docker-compose.prod.yml logs -f
```

#### 1.3 Configuración de SSL con Let's Encrypt

El docker-compose incluye Traefik que automáticamente obtendrá certificados SSL:

```bash
# Verificar que los certificados se generaron
docker exec -it traefik ls -la /certs/

# Los certificados se renuevan automáticamente
```

### 2. Despliegue en Vercel (Frontend) + Railway (Backend)

#### 2.1 Frontend en Vercel

```bash
# Instalar Vercel CLI
npm install -g vercel

# Navegar al directorio frontend
cd frontend

# Desplegar
vercel --prod

# Configurar variables de entorno en Vercel Dashboard
# REACT_APP_API_URL=https://tu-backend.railway.app
```

#### 2.2 Backend en Railway

1. Conectar repositorio a Railway
2. Configurar variables de entorno:
   ```
   NODE_ENV=production
   DATABASE_URL=postgresql://usuario:password@host:puerto/database
   JWT_SECRET=tu_jwt_secret
   PORT=5000
   CORS_ORIGIN=https://tu-frontend.vercel.app
   ```

### 3. Despliegue en AWS

#### 3.1 Usando AWS ECS (Elastic Container Service)

```bash
# Configurar AWS CLI
aws configure

# Crear repositorio ECR
aws ecr create-repository --repository-name sensuntepeque-backend
aws ecr create-repository --repository-name sensuntepeque-frontend

# Obtener comando de login
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin tu-account-id.dkr.ecr.us-east-1.amazonaws.com

# Construir y subir imágenes
docker build -t sensuntepeque-backend ./backend
docker tag sensuntepeque-backend:latest tu-account-id.dkr.ecr.us-east-1.amazonaws.com/sensuntepeque-backend:latest
docker push tu-account-id.dkr.ecr.us-east-1.amazonaws.com/sensuntepeque-backend:latest

docker build -t sensuntepeque-frontend ./frontend
docker tag sensuntepeque-frontend:latest tu-account-id.dkr.ecr.us-east-1.amazonaws.com/sensuntepeque-frontend:latest
docker push tu-account-id.dkr.ecr.us-east-1.amazonaws.com/sensuntepeque-frontend:latest
```

#### 3.2 Configuración de RDS (PostgreSQL)

```bash
# Crear instancia RDS
aws rds create-db-instance \
    --db-instance-identifier sensuntepeque-db \
    --db-instance-class db.t3.micro \
    --engine postgres \
    --master-username sensuntepeque_user \
    --master-user-password tu_password \
    --allocated-storage 20 \
    --db-name sensuntepeque_db
```

## 🔧 Configuración Post-Despliegue

### 1. Inicializar Base de Datos

```bash
# Si usas Docker
docker-compose -f docker-compose.prod.yml exec backend npm run db:setup

# Si usas despliegue separado
# Conectar a tu servidor y ejecutar:
npm run db:setup
```

### 2. Crear Usuario Administrador

```bash
# Acceder al contenedor/servidor
docker-compose -f docker-compose.prod.yml exec backend npm run create-admin

# O manualmente via API
curl -X POST https://api.sensuntepeque.com/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Administrador",
    "email": "admin@sensuntepeque.com",
    "password": "tu_password_seguro"
  }'
```

### 3. Configurar Backup Automático

```bash
# Agregar cron job para backups
echo "0 2 * * * docker-compose -f /ruta/a/docker-compose.prod.yml run --rm backup" | crontab -

# O usar script de backup
chmod +x scripts/backup.sh
echo "0 2 * * * /ruta/a/scripts/backup.sh" | crontab -
```

## 🛡️ Seguridad

### 1. Firewall

```bash
# Ubuntu/Debian
ufw allow 22/tcp  # SSH
ufw allow 80/tcp  # HTTP
ufw allow 443/tcp # HTTPS
ufw enable

# CentOS/RHEL
firewall-cmd --permanent --add-service=ssh
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --reload
```

### 2. Fail2Ban (Protección contra ataques)

```bash
# Instalar fail2ban
sudo apt install fail2ban

# Configurar para SSH
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 3. Monitoreo de Logs

```bash
# Ver logs de la aplicación
docker-compose -f docker-compose.prod.yml logs -f backend
docker-compose -f docker-compose.prod.yml logs -f frontend

# Configurar logrotate
sudo nano /etc/logrotate.d/sensuntepeque
```

## 📊 Monitoreo y Métricas

### 1. Health Checks

```bash
# Verificar estado de servicios
curl https://sensuntepeque.com/health
curl https://api.sensuntepeque.com/health

# Monitoreo con Uptime Robot o similar
```

### 2. Métricas con Prometheus (Opcional)

```yaml
# Agregar al docker-compose.prod.yml
prometheus:
  image: prom/prometheus
  ports:
    - "9090:9090"
  volumes:
    - ./prometheus.yml:/etc/prometheus/prometheus.yml

grafana:
  image: grafana/grafana
  ports:
    - "3001:3000"
  environment:
    - GF_SECURITY_ADMIN_PASSWORD=admin
```

## 🔄 Actualizaciones

### 1. Actualización con Docker

```bash
# Pull últimos cambios
git pull origin main

# Reconstruir imágenes
docker-compose -f docker-compose.prod.yml build

# Actualizar servicios
docker-compose -f docker-compose.prod.yml up -d

# Verificar
docker-compose -f docker-compose.prod.yml ps
```

### 2. Rollback

```bash
# Volver a versión anterior
git checkout [hash-del-commit-anterior]
docker-compose -f docker-compose.prod.yml build
docker-compose -f docker-compose.prod.yml up -d
```

## 📱 Configuración PWA

### 1. Service Worker

El service worker se genera automáticamente con Vite PWA plugin.

### 2. Manifest

Verificar que el manifest esté correctamente configurado en `frontend/public/manifest.json`.

## 🌐 CDN y Optimización

### 1. CloudFlare (Recomendado)

1. Registrar dominio en CloudFlare
2. Configurar DNS:
   ```
   A    sensuntepeque.com        [IP-del-servidor]
   A    www.sensuntepeque.com    [IP-del-servidor]
   CNAME api.sensuntepeque.com   sensuntepeque.com
   ```
3. Activar SSL/TLS Full (strict)
4. Activar minificación automática

### 2. Optimización de Imágenes

```bash
# Configurar Cloudinary para optimización automática
# Las imágenes se optimizan automáticamente según el dispositivo
```

## 🆘 Solución de Problemas

### Problemas Comunes

1. **Error de conexión a BD**
   ```bash
   # Verificar que PostgreSQL esté ejecutándose
   docker-compose -f docker-compose.prod.yml logs postgres
   
   # Verificar variables de entorno
   docker-compose -f docker-compose.prod.yml exec backend printenv | grep DATABASE
   ```

2. **Error 502 Bad Gateway**
   ```bash
   # Verificar que el backend esté ejecutándose
   docker-compose -f docker-compose.prod.yml logs backend
   
   # Verificar configuración de Nginx/Traefik
   ```

3. **Certificados SSL no se generan**
   ```bash
   # Verificar configuración de DNS
   nslookup sensuntepeque.com
   
   # Ver logs de Traefik
   docker-compose -f docker-compose.prod.yml logs traefik
   ```

## 📞 Soporte

Para obtener ayuda adicional:

1. **Documentación**: Revisar README.md y CONTRIBUTING.md
2. **Issues**: Crear issue en GitHub
3. **Logs**: Siempre incluir logs relevantes en reportes de problemas

---

## 🎯 Checklist Post-Despliegue

- [ ] ✅ Aplicación accesible en dominio principal
- [ ] 🔒 SSL configurado y funcionando
- [ ] 🗄️ Base de datos inicializada con datos de prueba
- [ ] 👤 Usuario administrador creado
- [ ] 📊 Health checks respondiendo correctamente
- [ ] 🔄 Backup automático configurado
- [ ] 🛡️ Firewall y seguridad configurados
- [ ] 📈 Monitoreo básico implementado
- [ ] 🌐 DNS configurado correctamente
- [ ] 📱 PWA funcionando (puede instalarse)

---

**¡Felicidades! 🎉 Sensuntepeque Cultural está ahora en producción, promoviendo la hermosa cultura de la Ciudad de los 400 Cerros.**