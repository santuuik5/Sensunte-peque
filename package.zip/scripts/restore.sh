#!/bin/bash

# Script de restauración para la base de datos de Sensuntepeque Cultural
# Autor: MiniMax Agent
# Uso: ./restore.sh <archivo_backup>

set -e

# Configuración
DB_HOST="postgres"
DB_NAME="sensuntepeque_db"
DB_USER="sensuntepeque_user"
BACKUP_FILE=$1

if [ -z "$BACKUP_FILE" ]; then
    echo "Uso: $0 <archivo_backup>"
    echo "Ejemplo: $0 /backups/sensuntepeque_backup_20241218_120000.sql.gz"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "Error: El archivo $BACKUP_FILE no existe"
    exit 1
fi

echo "[$(date)] Iniciando restauración desde: $BACKUP_FILE"

# Confirmar antes de continuar
read -p "¿Estás seguro de que quieres restaurar la base de datos? Esto sobrescribirá todos los datos actuales. (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Restauración cancelada"
    exit 1
fi

# Determinar si el archivo está comprimido
if [[ $BACKUP_FILE == *.gz ]]; then
    echo "[$(date)] Descomprimiendo archivo..."
    RESTORE_COMMAND="gunzip -c $BACKUP_FILE | psql -h $DB_HOST -U $DB_USER -d $DB_NAME"
else
    RESTORE_COMMAND="psql -h $DB_HOST -U $DB_USER -d $DB_NAME -f $BACKUP_FILE"
fi

# Realizar restauración
echo "[$(date)] Restaurando base de datos..."
eval $RESTORE_COMMAND

if [ $? -eq 0 ]; then
    echo "[$(date)] Restauración completada exitosamente"
else
    echo "[$(date)] Error durante la restauración"
    exit 1
fi

echo "[$(date)] Proceso de restauración finalizado"