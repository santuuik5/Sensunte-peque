#!/bin/bash

# Script de setup inicial para Sensuntepeque Cultural
# Autor: MiniMax Agent
# Este script configura el entorno completo de desarrollo

set -e

echo "🎆 Sensuntepeque Cultural - Setup Inicial"
echo "=========================================="
echo "🎭 La Ciudad de los 400 Cerros"
echo ""

# Verificar que Docker esté instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Docker no está instalado. Por favor, instala Docker y Docker Compose primero."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose no está instalado. Por favor, instala Docker Compose primero."
    exit 1
fi

echo "✅ Docker y Docker Compose detectados"

# Crear directorios necesarios
echo "📁 Creando directorios..."
mkdir -p backups
mkdir -p backend/uploads
mkdir -p logs
chmod +x scripts/*.sh

# Copiar archivos de configuración si no existen
if [ ! -f backend/.env ]; then
    echo "🔧 Creando archivo .env para el backend..."
    cp backend/.env.example backend/.env
    echo "⚠️  Por favor, revisa y ajusta las variables en backend/.env"
fi

if [ ! -f frontend/.env.local ]; then
    echo "🔧 Creando archivo .env.local para el frontend..."
    cat > frontend/.env.local << EOF
REACT_APP_API_URL=http://localhost:5000
REACT_APP_APP_NAME=Sensuntepeque Cultural
REACT_APP_VERSION=1.0.0
EOF
fi

# Instalar dependencias
echo "📦 Instalando dependencias..."
echo "Backend..."
cd backend && npm install
echo "Frontend..."
cd ../frontend && npm install
cd ..

# Levantar servicios con Docker
echo "🚀 Iniciando servicios con Docker..."
docker-compose up -d postgres redis

# Esperar a que PostgreSQL esté listo
echo "⏳ Esperando a que PostgreSQL esté listo..."
sleep 10

# Configurar base de datos
echo "💾 Configurando base de datos..."
cd backend
npm run db:setup
cd ..

echo ""
echo "✨ ¡Setup completado exitosamente!"
echo ""
echo "🚀 Para iniciar la aplicación en desarrollo:"
echo "   npm run dev"
echo ""
echo "👥 Credenciales de administrador por defecto:"
echo "   Email: admin@sensuntepeque.com"
echo "   Contraseña: admin123456"
echo ""
echo "🌍 URLs de acceso:"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:5000"
echo "   Documentación API: http://localhost:5000/api-docs"
echo ""
echo "🎭 ¡Bienvenido a Sensuntepeque Cultural!"
echo "   - Promoviendo la cultura de la ciudad de los 400 cerros"