#!/bin/bash

# Script de backup para la base de datos de Sensuntepeque Cultural
# Autor: MiniMax Agent
# Fecha: 2024

set -e

# Configuración
BACKUP_DIR="/backups"
DB_HOST="postgres"
DB_NAME="sensuntepeque_db"
DB_USER="sensuntepeque_user"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/sensuntepeque_backup_${TIMESTAMP}.sql"
RETENTION_DAYS=30

# Crear directorio de backup si no existe
mkdir -p $BACKUP_DIR

echo "[$(date)] Iniciando backup de la base de datos..."

# Realizar backup
pg_dump -h $DB_HOST -U $DB_USER -d $DB_NAME --no-password --verbose > $BACKUP_FILE

if [ $? -eq 0 ]; then
    echo "[$(date)] Backup completado exitosamente: $BACKUP_FILE"
    
    # Comprimir backup
    gzip $BACKUP_FILE
    echo "[$(date)] Backup comprimido: ${BACKUP_FILE}.gz"
    
    # Limpiar backups antiguos
    find $BACKUP_DIR -name "sensuntepeque_backup_*.sql.gz" -mtime +$RETENTION_DAYS -delete
    echo "[$(date)] Backups antiguos eliminados (mayores a $RETENTION_DAYS días)"
    
    # Mostrar estadísticas
    echo "[$(date)] Tamaño del backup: $(du -h ${BACKUP_FILE}.gz | cut -f1)"
    echo "[$(date)] Backups disponibles:"
    ls -lh $BACKUP_DIR/sensuntepeque_backup_*.sql.gz
else
    echo "[$(date)] Error al realizar el backup"
    exit 1
fi

echo "[$(date)] Proceso de backup finalizado"