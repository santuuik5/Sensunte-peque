import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

// Componentes base
import Layout from '@components/layout/Layout';
import ErrorBoundary from '@components/common/ErrorBoundary';
import LoadingSpinner from '@components/common/LoadingSpinner';
import ScrollToTop from '@components/common/ScrollToTop';

// Importaciones lazy para code splitting
const HomePage = lazy(() => import('@pages/HomePage'));
const HistoriaPage = lazy(() => import('@pages/HistoriaPage'));
const TradicionesPage = lazy(() => import('@pages/TradicionesPage'));
const GastronomiaPage = lazy(() => import('@pages/GastronomiaPage'));
const EventosPage = lazy(() => import('@pages/EventosPage'));
const LugaresPage = lazy(() => import('@pages/LugaresPage'));
const ArticlePage = lazy(() => import('@pages/ArticlePage'));
const TradicionPage = lazy(() => import('@pages/TradicionPage'));
const PlatoPage = lazy(() => import('@pages/PlatoPage'));
const EventoPage = lazy(() => import('@pages/EventoPage'));
const LugarPage = lazy(() => import('@pages/LugarPage'));
const NotFoundPage = lazy(() => import('@pages/NotFoundPage'));

// Animaciones para las transiciones de página
const pageVariants = {
  initial: {
    opacity: 0,
    y: 20,
  },
  in: {
    opacity: 1,
    y: 0,
  },
  out: {
    opacity: 0,
    y: -20,
  },
};

const pageTransition = {
  type: 'tween',
  ease: 'anticipate',
  duration: 0.5,
};

// Componente de fallback para Suspense
const PageFallback: React.FC = () => (
  <div className="min-h-screen flex items-center justify-center">
    <LoadingSpinner size="lg" />
  </div>
);

// Wrapper para animaciones de página
const AnimatedPage: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial="initial"
    animate="in"
    exit="out"
    variants={pageVariants}
    transition={pageTransition}
  >
    {children}
  </motion.div>
);

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <ScrollToTop />
      <Layout>
        <AnimatePresence mode="wait">
          <Suspense fallback={<PageFallback />}>
            <Routes>
              {/* Página principal */}
              <Route
                path="/"
                element={
                  <AnimatedPage>
                    <HomePage />
                  </AnimatedPage>
                }
              />
              
              {/* Sección de Historia */}
              <Route
                path="/historia"
                element={
                  <AnimatedPage>
                    <HistoriaPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/historia/:slug"
                element={
                  <AnimatedPage>
                    <ArticlePage />
                  </AnimatedPage>
                }
              />
              
              {/* Sección de Tradiciones */}
              <Route
                path="/tradiciones"
                element={
                  <AnimatedPage>
                    <TradicionesPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/tradiciones/:slug"
                element={
                  <AnimatedPage>
                    <TradicionPage />
                  </AnimatedPage>
                }
              />
              
              {/* Sección de Gastronomía */}
              <Route
                path="/gastronomia"
                element={
                  <AnimatedPage>
                    <GastronomiaPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/gastronomia/:slug"
                element={
                  <AnimatedPage>
                    <PlatoPage />
                  </AnimatedPage>
                }
              />
              
              {/* Sección de Eventos */}
              <Route
                path="/eventos"
                element={
                  <AnimatedPage>
                    <EventosPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/eventos/:slug"
                element={
                  <AnimatedPage>
                    <EventoPage />
                  </AnimatedPage>
                }
              />
              
              {/* Sección de Lugares */}
              <Route
                path="/lugares"
                element={
                  <AnimatedPage>
                    <LugaresPage />
                  </AnimatedPage>
                }
              />
              <Route
                path="/lugares/:slug"
                element={
                  <AnimatedPage>
                    <LugarPage />
                  </AnimatedPage>
                }
              />
              
              {/* Página 404 */}
              <Route
                path="*"
                element={
                  <AnimatedPage>
                    <NotFoundPage />
                  </AnimatedPage>
                }
              />
            </Routes>
          </Suspense>
        </AnimatePresence>
      </Layout>
    </ErrorBoundary>
  );
};

export default App;