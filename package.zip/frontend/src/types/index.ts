// Tipos base
export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

// Usuario
export interface User extends BaseEntity {
  name: string;
  email: string;
  role: 'USER' | 'ADMIN' | 'MODERATOR';
  isActive: boolean;
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  success: boolean;
  data: {
    token: string;
    user: AuthUser;
  };
  message: string;
}

// Artículos
export interface Article extends BaseEntity {
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  coverImage?: string;
  category: 'HISTORIA' | 'TRADICIONES' | 'GASTRONOMIA' | 'TURISMO' | 'CULTURA' | 'FESTIVALES' | 'PATRIMONIAL';
  isPublished: boolean;
  isFeatured: boolean;
  viewCount: number;
  publishedAt?: string;
  author: {
    id: string;
    name: string;
  };
  tags: Tag[];
  photos?: Photo[];
  comments?: Comment[];
  commentCount?: number;
}

// Tags
export interface Tag extends BaseEntity {
  name: string;
  slug: string;
  color?: string;
}

// Tradiciones
export interface Tradition extends BaseEntity {
  name: string;
  slug: string;
  description: string;
  content?: string;
  date?: string;
  month?: number;
  isActive: boolean;
  image?: string;
  gallery: string[];
}

// Platos
export interface Dish extends BaseEntity {
  name: string;
  slug: string;
  description: string;
  recipe?: string;
  ingredients: string[];
  image?: string;
  category: 'DESAYUNOS' | 'ALMUERZOS' | 'CENAS' | 'POSTRES' | 'BEBIDAS' | 'ANTOJITOS' | 'FESTIVALES';
  isTraditional: boolean;
  difficulty: 'FACIL' | 'INTERMEDIO' | 'DIFICIL';
  prepTime?: number;
  servings?: number;
  isPublished: boolean;
}

// Eventos
export interface Event extends BaseEntity {
  title: string;
  slug: string;
  description: string;
  content?: string;
  startDate: string;
  endDate?: string;
  location?: string;
  image?: string;
  category: 'RELIGIOSA' | 'CULTURAL' | 'GASTRONOMICA' | 'TURISTICA' | 'DEPORTIVA' | 'EDUCATIVA' | 'COMUNITARIA';
  isRecurring: boolean;
  isPublished: boolean;
  organizer: {
    id: string;
    name: string;
  };
  photos?: Photo[];
}

// Lugares
export interface Place extends BaseEntity {
  name: string;
  slug: string;
  description: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  category: 'HISTORICO' | 'RELIGIOSO' | 'NATURAL' | 'CULTURAL' | 'MIRADOR' | 'PLAZA' | 'MUSEO' | 'RESTAURANTE' | 'HOTEL';
  image?: string;
  gallery: string[];
  isPublic: boolean;
  isActive: boolean;
  openingHours?: string;
  contact?: string;
  website?: string;
  photos?: Photo[];
}

// Fotos
export interface Photo extends BaseEntity {
  title?: string;
  description?: string;
  url: string;
  altText?: string;
  category: 'GENERAL' | 'HISTORIA' | 'TRADICIONES' | 'GASTRONOMIA' | 'LUGARES' | 'EVENTOS' | 'PAISAJES' | 'ARQUITECTURA';
  isPublic: boolean;
  uploader: {
    id: string;
    name: string;
  };
}

// Comentarios
export interface Comment extends BaseEntity {
  content: string;
  isPublic: boolean;
  author: {
    id: string;
    name: string;
  };
  article: {
    id: string;
    title: string;
    slug: string;
  };
}

// Respuestas de API
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message: string;
}

export interface PaginatedResponse<T> extends ApiResponse<{
  items: T[];
  pagination: Pagination;
}> {}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// Estados de carga
export interface LoadingState {
  isLoading: boolean;
  error: string | null;
}

// Filtros y parámetros de búsqueda
export interface ArticleFilters {
  category?: string;
  featured?: boolean;
  page?: number;
  limit?: number;
}

export interface TraditionFilters {
  month?: number;
  active?: boolean;
}

export interface DishFilters {
  category?: string;
  difficulty?: string;
  traditional?: boolean;
}

export interface EventFilters {
  category?: string;
  upcoming?: boolean;
  month?: number;
}

export interface PlaceFilters {
  category?: string;
  active?: boolean;
}

// Tipos para formularios
export interface LoginForm {
  email: string;
  password: string;
}

export interface RegisterForm {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface ContactForm {
  name: string;
  email: string;
  subject: string;
  message: string;
}

// Tipos para configuración del sitio
export interface SiteConfig {
  siteName: string;
  siteDescription: string;
  cityName: string;
  cityDepartment: string;
  cityNickname: string;
  cityPatronSaint: string;
  cityPopulation: number;
  cityAltitude: number;
  cityCoordinates: {
    lat: number;
    lng: number;
  };
}

// Tipos de utilidad
export type Status = 'idle' | 'loading' | 'success' | 'error';

export type Theme = 'light' | 'dark' | 'system';

export type Language = 'es' | 'en';

export type SortOrder = 'asc' | 'desc';

export type ViewMode = 'grid' | 'list';

// Props comunes para componentes
export interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
}

export interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string[];
  image?: string;
  url?: string;
}

// Tipos para el store de estado
export interface AppState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  theme: Theme;
  language: Language;
  siteConfig: SiteConfig | null;
}

export interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Tipos para hooks personalizados
export interface UseApiOptions {
  enabled?: boolean;
  refetchOnMount?: boolean;
  refetchOnWindowFocus?: boolean;
  staleTime?: number;
  cacheTime?: number;
}

export interface UseLocalStorageOptions {
  defaultValue?: any;
  serialize?: (value: any) => string;
  deserialize?: (value: string) => any;
}

// Tipos para animaciones
export interface AnimationVariants {
  initial: any;
  animate: any;
  exit?: any;
}

export interface TransitionConfig {
  type?: string;
  duration?: number;
  ease?: string | number[];
  delay?: number;
}

// Error types
export interface ApiError {
  message: string;
  statusCode: number;
  timestamp: string;
  path: string;
  method: string;
  validationErrors?: Array<{
    field: string;
    message: string;
    value?: any;
  }>;
}

export interface AppError extends Error {
  statusCode?: number;
  isOperational?: boolean;
}