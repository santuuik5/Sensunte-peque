import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from 'react-hot-toast';

import App from './App';
import './index.css';

// Configuración de React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 3,
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
      staleTime: 5 * 60 * 1000, // 5 minutos
      cacheTime: 10 * 60 * 1000, // 10 minutos
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
    },
    mutations: {
      retry: 1,
    },
  },
});

// Configuración de Toast
const toastOptions = {
  duration: 4000,
  position: 'top-right' as const,
  style: {
    background: '#363636',
    color: '#fff',
    borderRadius: '8px',
    fontSize: '14px',
    maxWidth: '350px',
  },
  success: {
    style: {
      background: '#22c55e',
    },
    iconTheme: {
      primary: '#fff',
      secondary: '#22c55e',
    },
  },
  error: {
    style: {
      background: '#ef4444',
    },
    iconTheme: {
      primary: '#fff',
      secondary: '#ef4444',
    },
  },
};

// Función para manejar errores globales
const handleGlobalError = (error: Error) => {
  console.error('Error global de la aplicación:', error);
  // Aquí se podría enviar el error a un servicio de monitoreo
};

// Event listeners para errores globales
window.addEventListener('error', (event) => {
  handleGlobalError(event.error);
});

window.addEventListener('unhandledrejection', (event) => {
  handleGlobalError(new Error(event.reason));
});

// Renderizar la aplicación
const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <HelmetProvider>
        <BrowserRouter>
          <App />
          <Toaster toastOptions={toastOptions} />
        </BrowserRouter>
      </HelmetProvider>
    </QueryClientProvider>
  </React.StrictMode>
);

// Registrar service worker para PWA
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        console.log('SW registrado con éxito:', registration);
      })
      .catch((registrationError) => {
        console.log('Error al registrar SW:', registrationError);
      });
  });
}