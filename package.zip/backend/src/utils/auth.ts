import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { User } from '@prisma/client';
import { logger } from './logger';

// Configuración de bcrypt
const SALT_ROUNDS = 12;

/**
 * Hashear contraseña
 */
export const hashPassword = async (password: string): Promise<string> => {
  try {
    const salt = await bcrypt.genSalt(SALT_ROUNDS);
    return await bcrypt.hash(password, salt);
  } catch (error) {
    logger.error('Error hasheando contraseña:', error);
    throw new Error('Error procesando contraseña');
  }
};

/**
 * Verificar contraseña
 */
export const verifyPassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  try {
    return await bcrypt.compare(password, hashedPassword);
  } catch (error) {
    logger.error('Error verificando contraseña:', error);
    return false;
  }
};

/**
 * Generar token JWT
 */
export const generateToken = (user: Pick<User, 'id' | 'email' | 'role'>): string => {
  const jwtSecret = process.env.JWT_SECRET;
  const jwtExpires = process.env.JWT_EXPIRES_IN || '24h';
  
  if (!jwtSecret) {
    throw new Error('JWT_SECRET no está configurado');
  }
  
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role
  };
  
  return jwt.sign(payload, jwtSecret, { expiresIn: jwtExpires });
};

/**
 * Verificar token JWT
 */
export const verifyToken = (token: string): any => {
  const jwtSecret = process.env.JWT_SECRET;
  
  if (!jwtSecret) {
    throw new Error('JWT_SECRET no está configurado');
  }
  
  try {
    return jwt.verify(token, jwtSecret);
  } catch (error) {
    throw error;
  }
};

/**
 * Validar fortaleza de contraseña
 */
export const validatePasswordStrength = (password: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('La contraseña debe tener al menos 8 caracteres');
  }
  
  if (password.length > 128) {
    errors.push('La contraseña no puede exceder 128 caracteres');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('La contraseña debe incluir al menos una letra mayúscula');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('La contraseña debe incluir al menos una letra minúscula');
  }
  
  if (!/[0-9]/.test(password)) {
    errors.push('La contraseña debe incluir al menos un número');
  }
  
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('La contraseña debe incluir al menos un carácter especial');
  }
  
  // Verificar patrones comunes débiles
  const commonPasswords = ['password', '123456', 'admin', 'user', 'test'];
  if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
    errors.push('La contraseña no puede contener palabras comunes');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

/**
 * Generar contraseña aleatoria
 */
export const generateRandomPassword = (length: number = 12): string => {
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let password = '';
  
  // Asegurar que tenga al menos un carácter de cada tipo
  password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)];
  password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)];
  password += '0123456789'[Math.floor(Math.random() * 10)];
  password += '!@#$%^&*'[Math.floor(Math.random() * 8)];
  
  // Completar el resto
  for (let i = password.length; i < length; i++) {
    password += charset[Math.floor(Math.random() * charset.length)];
  }
  
  // Mezclar caracteres
  return password.split('').sort(() => Math.random() - 0.5).join('');
};