/**
 * Logger simple para la aplicación
 * En producción se puede reemplazar por Winston, Pino, etc.
 */

export interface LogLevel {
  ERROR: 0;
  WARN: 1;
  INFO: 2;
  DEBUG: 3;
}

const LOG_LEVELS: LogLevel = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3
};

const getCurrentLogLevel = (): number => {
  switch (process.env.LOG_LEVEL?.toUpperCase()) {
    case 'ERROR': return LOG_LEVELS.ERROR;
    case 'WARN': return LOG_LEVELS.WARN;
    case 'INFO': return LOG_LEVELS.INFO;
    case 'DEBUG': return LOG_LEVELS.DEBUG;
    default: return process.env.NODE_ENV === 'production' ? LOG_LEVELS.INFO : LOG_LEVELS.DEBUG;
  }
};

const formatMessage = (level: string, message: string, ...args: any[]): string => {
  const timestamp = new Date().toISOString();
  const formattedArgs = args.length > 0 ? ' ' + args.map(arg => 
    typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
  ).join(' ') : '';
  
  return `[${timestamp}] [${level}] ${message}${formattedArgs}`;
};

class Logger {
  private currentLevel: number;

  constructor() {
    this.currentLevel = getCurrentLogLevel();
  }

  error(message: string, ...args: any[]): void {
    if (this.currentLevel >= LOG_LEVELS.ERROR) {
      console.error(formatMessage('ERROR', message, ...args));
    }
  }

  warn(message: string, ...args: any[]): void {
    if (this.currentLevel >= LOG_LEVELS.WARN) {
      console.warn(formatMessage('WARN', message, ...args));
    }
  }

  info(message: string, ...args: any[]): void {
    if (this.currentLevel >= LOG_LEVELS.INFO) {
      console.info(formatMessage('INFO', message, ...args));
    }
  }

  debug(message: string, ...args: any[]): void {
    if (this.currentLevel >= LOG_LEVELS.DEBUG) {
      console.debug(formatMessage('DEBUG', message, ...args));
    }
  }

  // Método para logging de requests HTTP
  http(req: any, res: any, responseTime: number): void {
    const message = `${req.method} ${req.originalUrl} - ${res.statusCode} - ${responseTime}ms - ${req.ip}`;
    
    if (res.statusCode >= 400) {
      this.error(message);
    } else {
      this.info(message);
    }
  }

  // Método para logging de errores con stack trace
  logError(error: Error, context?: string): void {
    const contextMsg = context ? `[${context}] ` : '';
    this.error(`${contextMsg}${error.message}`);
    
    if (error.stack && this.currentLevel >= LOG_LEVELS.DEBUG) {
      this.debug('Stack trace:', error.stack);
    }
  }
}

export const logger = new Logger();
export default logger;