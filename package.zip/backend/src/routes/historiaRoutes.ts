import { Router } from 'express';
import {
  getHistoriaArticles,
  getHistoriaBySlug,
  createHistoriaArticle
} from '../controllers/historiaController';
import { authenticateToken, requireModerator } from '../middleware/auth';
import { validatePagination, validateId } from '../middleware/validation';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Historia
 *   description: Artículos históricos de Sensuntepeque
 */

// Rutas públicas
router.get('/', validatePagination, getHistoriaArticles);
router.get('/:slug', getHistoriaBySlug);

// Rutas protegidas (solo moderadores y administradores)
router.post('/', authenticateToken, requireModerator, createHistoriaArticle);

export default router;