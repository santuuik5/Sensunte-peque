import { Router } from 'express';
import { Request, Response } from 'express';
import { prisma, checkDatabaseHealth } from '../database/connection';
import { authenticateToken, requireAdmin } from '../middleware/auth';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Administración
 *   description: Endpoints administrativos (solo administradores)
 */

// Middleware para todas las rutas admin
router.use(authenticateToken);
router.use(requireAdmin);

/**
 * @swagger
 * /api/admin/dashboard:
 *   get:
 *     tags: [Administración]
 *     summary: Obtener datos del dashboard administrativo
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Datos del dashboard
 *       403:
 *         description: Acceso denegado
 */
router.get('/dashboard', asyncHandler(async (req: Request, res: Response) => {
  // Obtener estadísticas generales
  const [stats, dbHealth] = await Promise.all([
    Promise.all([
      prisma.article.count(),
      prisma.article.count({ where: { isPublished: true } }),
      prisma.dish.count(),
      prisma.event.count(),
      prisma.place.count(),
      prisma.tradition.count(),
      prisma.user.count(),
      prisma.user.count({ where: { isActive: true } }),
      prisma.photo.count(),
      prisma.comment.count(),
      prisma.comment.count({ where: { isPublic: true } })
    ]),
    checkDatabaseHealth()
  ]);
  
  const [
    totalArticles,
    publishedArticles,
    totalDishes,
    totalEvents,
    totalPlaces,
    totalTraditions,
    totalUsers,
    activeUsers,
    totalPhotos,
    totalComments,
    publicComments
  ] = stats;
  
  // Artículos recientes
  const recentArticles = await prisma.article.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      title: true,
      category: true,
      isPublished: true,
      viewCount: true,
      createdAt: true,
      author: {
        select: {
          name: true
        }
      }
    }
  });
  
  // Usuarios recientes
  const recentUsers = await prisma.user.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isActive: true,
      createdAt: true
    }
  });
  
  // Comentarios pendientes de moderación
  const pendingComments = await prisma.comment.findMany({
    where: { isPublic: false },
    take: 10,
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      content: true,
      createdAt: true,
      author: {
        select: {
          name: true
        }
      },
      article: {
        select: {
          title: true
        }
      }
    }
  });
  
  res.json({
    success: true,
    data: {
      statistics: {
        content: {
          articles: {
            total: totalArticles,
            published: publishedArticles,
            draft: totalArticles - publishedArticles
          },
          dishes: totalDishes,
          events: totalEvents,
          places: totalPlaces,
          traditions: totalTraditions,
          photos: totalPhotos
        },
        users: {
          total: totalUsers,
          active: activeUsers,
          inactive: totalUsers - activeUsers
        },
        engagement: {
          comments: {
            total: totalComments,
            public: publicComments,
            pending: totalComments - publicComments
          }
        }
      },
      recent: {
        articles: recentArticles,
        users: recentUsers
      },
      pending: {
        comments: pendingComments
      },
      system: {
        database: dbHealth,
        timestamp: new Date().toISOString()
      }
    },
    message: 'Dashboard obtenido exitosamente'
  });
}));

/**
 * @swagger
 * /api/admin/users:
 *   get:
 *     tags: [Administración]
 *     summary: Obtener lista de usuarios
 *     security:
 *       - bearerAuth: []
 */
router.get('/users', asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
  const skip = (page - 1) * limit;
  
  const [users, total] = await Promise.all([
    prisma.user.findMany({
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            articles: true,
            events: true,
            photos: true,
            comments: true
          }
        }
      }
    }),
    prisma.user.count()
  ]);
  
  res.json({
    success: true,
    data: {
      users,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    },
    message: 'Usuarios obtenidos exitosamente'
  });
}));

/**
 * @swagger
 * /api/admin/users/{id}/toggle-status:
 *   patch:
 *     tags: [Administración]
 *     summary: Activar/desactivar usuario
 *     security:
 *       - bearerAuth: []
 */
router.patch('/users/:id/toggle-status', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  
  const user = await prisma.user.findUnique({
    where: { id },
    select: { id: true, isActive: true, email: true }
  });
  
  if (!user) {
    throw createError('Usuario no encontrado', 404);
  }
  
  const updatedUser = await prisma.user.update({
    where: { id },
    data: {
      isActive: !user.isActive
    },
    select: {
      id: true,
      name: true,
      email: true,
      isActive: true,
      updatedAt: true
    }
  });
  
  logger.info(`Usuario ${user.email} ${updatedUser.isActive ? 'activado' : 'desactivado'}`);
  
  res.json({
    success: true,
    data: { user: updatedUser },
    message: `Usuario ${updatedUser.isActive ? 'activado' : 'desactivado'} exitosamente`
  });
}));

/**
 * @swagger
 * /api/admin/comments/moderate:
 *   get:
 *     tags: [Administración]
 *     summary: Obtener comentarios pendientes de moderación
 *     security:
 *       - bearerAuth: []
 */
router.get('/comments/moderate', asyncHandler(async (req: Request, res: Response) => {
  const comments = await prisma.comment.findMany({
    where: { isPublic: false },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      content: true,
      createdAt: true,
      author: {
        select: {
          id: true,
          name: true,
          email: true
        }
      },
      article: {
        select: {
          id: true,
          title: true,
          slug: true
        }
      }
    }
  });
  
  res.json({
    success: true,
    data: {
      comments,
      total: comments.length
    },
    message: 'Comentarios pendientes obtenidos exitosamente'
  });
}));

/**
 * @swagger
 * /api/admin/comments/{id}/approve:
 *   patch:
 *     tags: [Administración]
 *     summary: Aprobar comentario
 *     security:
 *       - bearerAuth: []
 */
router.patch('/comments/:id/approve', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  
  const comment = await prisma.comment.update({
    where: { id },
    data: { isPublic: true },
    select: {
      id: true,
      content: true,
      isPublic: true,
      author: {
        select: {
          name: true
        }
      }
    }
  });
  
  res.json({
    success: true,
    data: { comment },
    message: 'Comentario aprobado exitosamente'
  });
}));

/**
 * @swagger
 * /api/admin/system/health:
 *   get:
 *     tags: [Administración]
 *     summary: Verificar salud del sistema
 *     security:
 *       - bearerAuth: []
 */
router.get('/system/health', asyncHandler(async (req: Request, res: Response) => {
  const dbHealth = await checkDatabaseHealth();
  
  res.json({
    success: true,
    data: {
      database: dbHealth,
      server: {
        status: 'healthy',
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        timestamp: new Date().toISOString()
      }
    },
    message: 'Estado del sistema obtenido exitosamente'
  });
}));

export default router;