import { Router } from 'express';
import {
  getEventos,
  getEventoBySlug,
  createEvento,
  getFestivales
} from '../controllers/eventosController';
import { authenticateToken, requireModerator } from '../middleware/auth';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Eventos
 *   description: Eventos y festivales de Sensuntepeque
 */

// Rutas públicas
router.get('/', getEventos);
router.get('/festivales', getFestivales);
router.get('/:slug', getEventoBySlug);

// Rutas protegidas
router.post('/', authenticateToken, requireModerator, createEvento);

export default router;