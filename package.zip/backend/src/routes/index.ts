import { Application } from 'express';
import authRoutes from './authRoutes';
import historiaRoutes from './historiaRoutes';
import tradicionesRoutes from './tradicionesRoutes';
import gastronomiaRoutes from './gastronomiaRoutes';
import eventosRoutes from './eventosRoutes';
import lugaresRoutes from './lugaresRoutes';
import adminRoutes from './adminRoutes';

/**
 * Configurar todas las rutas principales de la aplicación
 */
export const setupRoutes = (app: Application): void => {
  const apiPrefix = process.env.API_PREFIX || '/api';
  
  // Rutas de autenticación
  app.use(`${apiPrefix}/auth`, authRoutes);
  
  // Rutas de contenido público
  app.use(`${apiPrefix}/historia`, historiaRoutes);
  app.use(`${apiPrefix}/tradiciones`, tradicionesRoutes);
  app.use(`${apiPrefix}/gastronomia`, gastronomiaRoutes);
  app.use(`${apiPrefix}/eventos`, eventosRoutes);
  app.use(`${apiPrefix}/lugares`, lugaresRoutes);
  
  // Rutas administrativas
  app.use(`${apiPrefix}/admin`, adminRoutes);
  
  // Ruta de información de la API
  app.get(`${apiPrefix}`, (req, res) => {
    res.json({
      success: true,
      message: 'Sensuntepeque Cultural API',
      version: '1.0.0',
      endpoints: {
        auth: `${apiPrefix}/auth`,
        historia: `${apiPrefix}/historia`,
        tradiciones: `${apiPrefix}/tradiciones`,
        gastronomia: `${apiPrefix}/gastronomia`,
        eventos: `${apiPrefix}/eventos`,
        lugares: `${apiPrefix}/lugares`,
        admin: `${apiPrefix}/admin`
      },
      documentation: '/api-docs',
      health: '/health'
    });
  });
};