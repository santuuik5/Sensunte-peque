import { Router } from 'express';
import {
  getLugares,
  getLugarBySlug,
  createLugar,
  getLugaresEmblematicos
} from '../controllers/lugaresController';
import { authenticateToken, requireModerator } from '../middleware/auth';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Lugares
 *   description: Lugares turísticos de Sensuntepeque
 */

// Rutas públicas
router.get('/', getLugares);
router.get('/emblematicos', getLugaresEmblematicos);
router.get('/:slug', getLugarBySlug);

// Rutas protegidas
router.post('/', authenticateToken, requireModerator, createLugar);

export default router;