import { Router } from 'express';
import {
  getTradiciones,
  getTradicionBySlug,
  createTradicion,
  getTradicionesFamosas
} from '../controllers/tradicionesController';
import { authenticateToken, requireModerator } from '../middleware/auth';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Tradiciones
 *   description: Tradiciones y costumbres de Sensuntepeque
 */

// Rutas públicas
router.get('/', getTradiciones);
router.get('/famosas', getTradicionesFamosas);
router.get('/:slug', getTradicionBySlug);

// Rutas protegidas
router.post('/', authenticateToken, requireModerator, createTradicion);

export default router;