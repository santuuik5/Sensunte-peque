import { Router } from 'express';
import {
  getPlatos,
  getPlatoBySlug,
  createPlato,
  getPlatosTipicos
} from '../controllers/gastronomiaController';
import { authenticateToken, requireModerator } from '../middleware/auth';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Gastronomía
 *   description: Platos típicos y gastronomía de Sensuntepeque
 */

// Rutas públicas
router.get('/', getPlatos);
router.get('/tipicos', getPlatosTipicos);
router.get('/:slug', getPlatoBySlug);

// Rutas protegidas
router.post('/', authenticateToken, requireModerator, createPlato);

export default router;