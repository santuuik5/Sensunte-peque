import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../database/connection';
import { createError, asyncHandler } from './errorHandler';
import { logger } from '../utils/logger';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    role: string;
  };
}

// Middleware para verificar token JWT
export const authenticateToken = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    throw createError('Token de acceso requerido', 401);
  }

  try {
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      throw createError('JWT_SECRET no está configurado', 500);
    }

    const decoded = jwt.verify(token, jwtSecret) as any;
    
    // Verificar que el usuario existe y está activo
    const user = await prisma.user.findUnique({
      where: { 
        id: decoded.userId,
        isActive: true 
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true
      }
    });

    if (!user) {
      throw createError('Usuario no encontrado o inactivo', 401);
    }

    req.user = user;
    next();
    
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      throw createError('Token inválido', 401);
    }
    if (error instanceof jwt.TokenExpiredError) {
      throw createError('Token expirado', 401);
    }
    throw error;
  }
});

// Middleware para verificar roles
export const requireRole = (roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      throw createError('Usuario no autenticado', 401);
    }

    if (!roles.includes(req.user.role)) {
      logger.warn(`Acceso denegado para usuario ${req.user.email} con rol ${req.user.role}`);
      throw createError('No tienes permisos para acceder a este recurso', 403);
    }

    next();
  };
};

// Middleware para requerir rol de administrador
export const requireAdmin = requireRole(['ADMIN']);

// Middleware para requerir rol de administrador o moderador
export const requireModerator = requireRole(['ADMIN', 'MODERATOR']);

// Middleware opcional de autenticación (no falla si no hay token)
export const optionalAuth = asyncHandler(async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return next();
  }

  try {
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      return next();
    }

    const decoded = jwt.verify(token, jwtSecret) as any;
    
    const user = await prisma.user.findUnique({
      where: { 
        id: decoded.userId,
        isActive: true 
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true
      }
    });

    if (user) {
      req.user = user;
    }
    
  } catch (error) {
    // Silenciar errores en autenticación opcional
    logger.debug('Error en autenticación opcional:', error);
  }

  next();
});