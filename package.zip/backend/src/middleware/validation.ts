import { Request, Response, NextFunction } from 'express';
import { validationResult, ValidationChain } from 'express-validator';
import { createError } from './errorHandler';

// Middleware para manejar errores de validación
export const handleValidationErrors = (req: Request, res: Response, next: NextFunction) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const formattedErrors = errors.array().map(error => ({
      field: error.type === 'field' ? (error as any).path : 'unknown',
      message: error.msg,
      value: error.type === 'field' ? (error as any).value : undefined
    }));
    
    return res.status(400).json({
      success: false,
      error: {
        message: 'Errores de validación',
        statusCode: 400,
        timestamp: new Date().toISOString(),
        validationErrors: formattedErrors
      }
    });
  }
  
  next();
};

// Función helper para ejecutar validaciones
export const validate = (validations: ValidationChain[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Ejecutar todas las validaciones
    for (const validation of validations) {
      const result = await validation.run(req);
      if (!result.isEmpty()) {
        break;
      }
    }
    
    // Manejar errores de validación
    handleValidationErrors(req, res, next);
  };
};

// Middleware para validar IDs de parámetros
export const validateId = (paramName: string = 'id') => {
  return (req: Request, res: Response, next: NextFunction) => {
    const id = req.params[paramName];
    
    if (!id || typeof id !== 'string' || id.trim().length === 0) {
      throw createError(`Parámetro ${paramName} inválido`, 400);
    }
    
    // Validación básica para CUID (usado por Prisma)
    const cuidRegex = /^[a-z0-9]{25}$/;
    if (!cuidRegex.test(id)) {
      throw createError(`Formato de ${paramName} inválido`, 400);
    }
    
    next();
  };
};

// Middleware para validar consultas de paginación
export const validatePagination = (req: Request, res: Response, next: NextFunction) => {
  const { page, limit, skip } = req.query;
  
  if (page && (isNaN(Number(page)) || Number(page) < 1)) {
    throw createError('El parámetro page debe ser un número mayor a 0', 400);
  }
  
  if (limit && (isNaN(Number(limit)) || Number(limit) < 1 || Number(limit) > 100)) {
    throw createError('El parámetro limit debe ser un número entre 1 y 100', 400);
  }
  
  if (skip && (isNaN(Number(skip)) || Number(skip) < 0)) {
    throw createError('El parámetro skip debe ser un número mayor o igual a 0', 400);
  }
  
  next();
};

// Sanitizar entrada de texto
export const sanitizeText = (text: string): string => {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  return text
    .trim()
    .replace(/[<>"'&]/g, '') // Remover caracteres peligrosos
    .substring(0, 1000); // Limitar longitud
};

// Generar slug desde texto
export const generateSlug = (text: string): string => {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Remover caracteres especiales
    .replace(/[\s_-]+/g, '-') // Reemplazar espacios con guiones
    .replace(/^-+|-+$/g, ''); // Remover guiones al inicio/final
};