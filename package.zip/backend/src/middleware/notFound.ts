import { Request, Response } from 'express';
import { logger } from '../utils/logger';

export const notFound = (req: Request, res: Response) => {
  const message = `Ruta no encontrada: ${req.method} ${req.originalUrl}`;
  
  logger.warn(message);
  
  res.status(404).json({
    success: false,
    error: {
      message: 'Ruta no encontrada',
      statusCode: 404,
      path: req.originalUrl,
      method: req.method,
      timestamp: new Date().toISOString(),
      suggestion: 'Verifica la URL y el método HTTP. Consulta la documentación en /api-docs'
    }
  });
};