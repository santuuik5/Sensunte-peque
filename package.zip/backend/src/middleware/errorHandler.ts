import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export interface AppError extends Error {
  statusCode?: number;
  isOperational?: boolean;
}

export const createError = (message: string, statusCode: number = 500): AppError => {
  const error: AppError = new Error(message);
  error.statusCode = statusCode;
  error.isOperational = true;
  return error;
};

export const errorHandler = (err: AppError, req: Request, res: Response, next: NextFunction) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Error interno del servidor';
  
  // Log del error
  logger.logError(err, `${req.method} ${req.originalUrl}`);
  
  // En desarrollo, enviar stack trace
  const errorResponse: any = {
    success: false,
    error: {
      message,
      statusCode,
      timestamp: new Date().toISOString(),
      path: req.originalUrl,
      method: req.method
    }
  };
  
  if (process.env.NODE_ENV === 'development') {
    errorResponse.error.stack = err.stack;
  }
  
  // Errores específicos de Prisma
  if (err.name === 'PrismaClientKnownRequestError') {
    const prismaError = err as any;
    
    switch (prismaError.code) {
      case 'P2002':
        errorResponse.error.message = 'Ya existe un registro con estos datos únicos';
        errorResponse.error.statusCode = 409;
        break;
      case 'P2025':
        errorResponse.error.message = 'Registro no encontrado';
        errorResponse.error.statusCode = 404;
        break;
      default:
        errorResponse.error.message = 'Error en la base de datos';
        errorResponse.error.statusCode = 500;
    }
  }
  
  // Errores de validación
  if (err.name === 'ValidationError') {
    errorResponse.error.message = 'Datos de entrada inválidos';
    errorResponse.error.statusCode = 400;
  }
  
  // Errores de JWT
  if (err.name === 'JsonWebTokenError') {
    errorResponse.error.message = 'Token inválido';
    errorResponse.error.statusCode = 401;
  }
  
  if (err.name === 'TokenExpiredError') {
    errorResponse.error.message = 'Token expirado';
    errorResponse.error.statusCode = 401;
  }
  
  res.status(errorResponse.error.statusCode).json(errorResponse);
};

// Middleware para manejar errores async/await
export const asyncHandler = (fn: Function) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};