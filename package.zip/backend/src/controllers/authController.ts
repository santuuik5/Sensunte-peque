import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { hashPassword, verifyPassword, generateToken, validatePasswordStrength } from '../utils/auth';
import { sanitizeText } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags: [Autenticación]
 *     summary: Iniciar sesión
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Login exitoso
 *       401:
 *         description: Credenciales inválidas
 */
export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    throw createError('Email y contraseña son requeridos', 400);
  }
  
  // Buscar usuario
  const user = await prisma.user.findUnique({
    where: { 
      email: email.toLowerCase().trim(),
      isActive: true 
    }
  });
  
  if (!user) {
    logger.warn(`Intento de login con email inexistente: ${email}`);
    throw createError('Credenciales inválidas', 401);
  }
  
  // Verificar contraseña
  const isValidPassword = await verifyPassword(password, user.password);
  
  if (!isValidPassword) {
    logger.warn(`Intento de login con contraseña incorrecta: ${email}`);
    throw createError('Credenciales inválidas', 401);
  }
  
  // Generar token
  const token = generateToken({
    id: user.id,
    email: user.email,
    role: user.role
  });
  
  logger.info(`Login exitoso para usuario: ${user.email}`);
  
  res.json({
    success: true,
    data: {
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role
      }
    },
    message: 'Login exitoso'
  });
});

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     tags: [Autenticación]
 *     summary: Registrar nuevo usuario
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 minLength: 8
 *     responses:
 *       201:
 *         description: Usuario registrado exitosamente
 *       400:
 *         description: Datos inválidos
 *       409:
 *         description: Email ya existe
 */
export const register = asyncHandler(async (req: Request, res: Response) => {
  const { name, email, password } = req.body;
  
  // Validaciones básicas
  if (!name || !email || !password) {
    throw createError('Nombre, email y contraseña son requeridos', 400);
  }
  
  // Validar email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    throw createError('Formato de email inválido', 400);
  }
  
  // Validar fortaleza de contraseña
  const passwordValidation = validatePasswordStrength(password);
  if (!passwordValidation.isValid) {
    throw createError(`Contraseña débil: ${passwordValidation.errors.join(', ')}`, 400);
  }
  
  // Verificar si el email ya existe
  const existingUser = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() }
  });
  
  if (existingUser) {
    throw createError('Ya existe un usuario con este email', 409);
  }
  
  // Hashear contraseña
  const hashedPassword = await hashPassword(password);
  
  // Crear usuario
  const user = await prisma.user.create({
    data: {
      name: sanitizeText(name),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      role: 'USER' // Por defecto es USER
    },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      createdAt: true
    }
  });
  
  logger.info(`Nuevo usuario registrado: ${user.email}`);
  
  res.status(201).json({
    success: true,
    data: { user },
    message: 'Usuario registrado exitosamente'
  });
});

/**
 * @swagger
 * /api/auth/profile:
 *   get:
 *     tags: [Autenticación]
 *     summary: Obtener perfil del usuario autenticado
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Perfil del usuario
 *       401:
 *         description: No autenticado
 */
export const getProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isActive: true,
      createdAt: true,
      updatedAt: true,
      _count: {
        select: {
          articles: true,
          events: true,
          photos: true,
          comments: true
        }
      }
    }
  });
  
  if (!user) {
    throw createError('Usuario no encontrado', 404);
  }
  
  res.json({
    success: true,
    data: { user },
    message: 'Perfil obtenido exitosamente'
  });
});

/**
 * @swagger
 * /api/auth/update-profile:
 *   put:
 *     tags: [Autenticación]
 *     summary: Actualizar perfil del usuario
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Perfil actualizado
 *       401:
 *         description: No autenticado
 */
export const updateProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const { name } = req.body;
  
  if (!name || name.trim().length === 0) {
    throw createError('El nombre es requerido', 400);
  }
  
  const updatedUser = await prisma.user.update({
    where: { id: req.user.id },
    data: {
      name: sanitizeText(name)
    },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      updatedAt: true
    }
  });
  
  logger.info(`Perfil actualizado para usuario: ${updatedUser.email}`);
  
  res.json({
    success: true,
    data: { user: updatedUser },
    message: 'Perfil actualizado exitosamente'
  });
});

/**
 * @swagger
 * /api/auth/change-password:
 *   put:
 *     tags: [Autenticación]
 *     summary: Cambiar contraseña
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               currentPassword:
 *                 type: string
 *               newPassword:
 *                 type: string
 *                 minLength: 8
 *     responses:
 *       200:
 *         description: Contraseña cambiada exitosamente
 *       400:
 *         description: Contraseña actual incorrecta
 *       401:
 *         description: No autenticado
 */
export const changePassword = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const { currentPassword, newPassword } = req.body;
  
  if (!currentPassword || !newPassword) {
    throw createError('Contraseña actual y nueva contraseña son requeridas', 400);
  }
  
  // Obtener usuario con contraseña
  const user = await prisma.user.findUnique({
    where: { id: req.user.id }
  });
  
  if (!user) {
    throw createError('Usuario no encontrado', 404);
  }
  
  // Verificar contraseña actual
  const isValidCurrentPassword = await verifyPassword(currentPassword, user.password);
  
  if (!isValidCurrentPassword) {
    throw createError('Contraseña actual incorrecta', 400);
  }
  
  // Validar nueva contraseña
  const passwordValidation = validatePasswordStrength(newPassword);
  if (!passwordValidation.isValid) {
    throw createError(`Nueva contraseña débil: ${passwordValidation.errors.join(', ')}`, 400);
  }
  
  // Verificar que la nueva contraseña sea diferente
  const isSamePassword = await verifyPassword(newPassword, user.password);
  if (isSamePassword) {
    throw createError('La nueva contraseña debe ser diferente a la actual', 400);
  }
  
  // Hashear nueva contraseña
  const hashedNewPassword = await hashPassword(newPassword);
  
  // Actualizar contraseña
  await prisma.user.update({
    where: { id: req.user.id },
    data: {
      password: hashedNewPassword
    }
  });
  
  logger.info(`Contraseña cambiada para usuario: ${user.email}`);
  
  res.json({
    success: true,
    message: 'Contraseña cambiada exitosamente'
  });
});