import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { sanitizeText, generateSlug } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/eventos:
 *   get:
 *     tags: [Eventos]
 *     summary: Obtener eventos de Sensuntepeque
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *           enum: [RELIGIOSA, CULTURAL, GASTRONOMICA, TURISTICA, DEPORTIVA, EDUCATIVA, COMUNITARIA]
 *       - in: query
 *         name: upcoming
 *         schema:
 *           type: boolean
 *         description: Solo eventos futuros
 *       - in: query
 *         name: month
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *     responses:
 *       200:
 *         description: Lista de eventos
 */
export const getEventos = asyncHandler(async (req: Request, res: Response) => {
  const { category, upcoming, month } = req.query;
  const now = new Date();
  
  const where: any = {
    isPublished: true
  };
  
  if (category) where.category = category;
  if (upcoming === 'true') {
    where.startDate = { gte: now };
  }
  if (month) {
    const startOfMonth = new Date(now.getFullYear(), parseInt(month as string) - 1, 1);
    const endOfMonth = new Date(now.getFullYear(), parseInt(month as string), 0, 23, 59, 59);
    where.startDate = {
      gte: startOfMonth,
      lte: endOfMonth
    };
  }
  
  const eventos = await prisma.event.findMany({
    where,
    orderBy: [
      { startDate: 'asc' }
    ],
    select: {
      id: true,
      title: true,
      slug: true,
      description: true,
      startDate: true,
      endDate: true,
      location: true,
      image: true,
      category: true,
      isRecurring: true,
      organizer: {
        select: {
          id: true,
          name: true
        }
      },
      _count: {
        select: {
          photos: true
        }
      }
    }
  });
  
  res.json({
    success: true,
    data: {
      eventos,
      total: eventos.length,
      stats: {
        proximos: eventos.filter(e => new Date(e.startDate) >= now).length,
        pasados: eventos.filter(e => new Date(e.startDate) < now).length,
        recurrentes: eventos.filter(e => e.isRecurring).length
      }
    },
    message: 'Eventos obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/eventos/{slug}:
 *   get:
 *     tags: [Eventos]
 *     summary: Obtener evento por slug
 */
export const getEventoBySlug = asyncHandler(async (req: Request, res: Response) => {
  const { slug } = req.params;
  
  const evento = await prisma.event.findFirst({
    where: {
      slug,
      isPublished: true
    },
    include: {
      organizer: {
        select: {
          id: true,
          name: true
        }
      },
      photos: {
        select: {
          id: true,
          title: true,
          url: true,
          altText: true
        }
      }
    }
  });
  
  if (!evento) {
    throw createError('Evento no encontrado', 404);
  }
  
  // Eventos relacionados
  const relacionados = await prisma.event.findMany({
    where: {
      category: evento.category,
      isPublished: true,
      id: { not: evento.id }
    },
    take: 3,
    orderBy: {
      startDate: 'desc'
    },
    select: {
      id: true,
      title: true,
      slug: true,
      description: true,
      startDate: true,
      image: true
    }
  });
  
  res.json({
    success: true,
    data: {
      evento,
      relacionados
    },
    message: 'Evento obtenido exitosamente'
  });
});

/**
 * @swagger
 * /api/eventos/festivales:
 *   get:
 *     tags: [Eventos]
 *     summary: Obtener festivales principales de Sensuntepeque
 */
export const getFestivales = asyncHandler(async (req: Request, res: Response) => {
  // Festivales principales basados en la investigación
  const festivales = [
    {
      title: 'Fiestas Patronales de Santa Bárbara',
      description: 'Las fiestas patronales más importantes de Sensuntepeque, con procesiones, ferias, música y comida tradicional.',
      startDate: '2024-11-24',
      endDate: '2024-12-05',
      location: 'Centro de Sensuntepeque',
      category: 'RELIGIOSA',
      isRecurring: true,
      highlights: [
        'Procesiones religiosas',
        'Las "Recordadas" (serenatas matutinas)',
        'Feria gastronómica',
        'Juegos mecánicos',
        'Conciertos musicales',
        'Distribución de atol shuco'
      ],
      patrona: 'Santa Bárbara',
      iglesia: 'Iglesia Parroquial Santa Bárbara'
    },
    {
      title: 'Fiesta de la Virgen del Tránsito',
      description: 'Celebración religiosa en honor a la Virgen del Tránsito, segunda festividad patronal de la ciudad.',
      startDate: '2024-08-15',
      endDate: '2024-08-15',
      location: 'Iglesia y calles del centro',
      category: 'RELIGIOSA',
      isRecurring: true,
      highlights: [
        'Procesión solemne',
        'Misa especial',
        'Alfombras de flores',
        'Coros y música sacra'
      ]
    },
    {
      title: 'Festival Turístico de Cabañas Este',
      description: 'Festival que promueve el turismo y la identidad cultural de la región oriental del departamento de Cabañas.',
      startDate: '2024-07-15',
      endDate: '2024-07-16',
      location: 'Plaza Central y alrededores',
      category: 'TURISTICA',
      isRecurring: true,
      highlights: [
        'Exposición de artesanías',
        'Gastronomía local',
        'Presentaciones culturales',
        'Promoción turística',
        'Actividades familiares'
      ],
      organizador: 'ADICI Cabañas Este'
    },
    {
      title: 'Festival Cultural en Incagua',
      description: 'Festival cultural que se realiza en la zona de Incagua, promoviendo las tradiciones locales.',
      startDate: '2024-06-20',
      endDate: '2024-06-21',
      location: 'Incagua, Sensuntepeque',
      category: 'CULTURAL',
      isRecurring: true,
      highlights: [
        'Danzas folclóricas',
        'Música tradicional',
        'Comida típica',
        'Actividades acuicas',
        'Artistas locales'
      ]
    },
    {
      title: 'Celebración de Los Fogones',
      description: 'Tradición única donde se queman hojas en las cunetas como celebración de la víspera de la Inmaculada Concepción.',
      startDate: '2024-12-07',
      endDate: '2024-12-07',
      location: 'Calles de toda la ciudad',
      category: 'CULTURAL',
      isRecurring: true,
      highlights: [
        'Recoleción comunitaria de hojas',
        'Encendido simultáneo a las 6:00 PM',
        'Tradición familiar',
        'Ambiente festivo en las calles'
      ],
      horario: '6:00 PM',
      participacion: 'Toda la comunidad'
    }
  ];
  
  res.json({
    success: true,
    data: {
      festivales,
      total: festivales.length,
      info: {
        ciudad: 'Sensuntepeque',
        departamento: 'Cabañas',
        patrona: 'Santa Bárbara',
        tradicionMasImportante: 'Las Recordadas y Los Fogones'
      }
    },
    message: 'Festivales de Sensuntepeque obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/eventos:
 *   post:
 *     tags: [Eventos]
 *     summary: Crear nuevo evento (Admin)
 */
export const createEvento = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const {
    title,
    description,
    content,
    startDate,
    endDate,
    location,
    image,
    category,
    isRecurring = false
  } = req.body;
  
  if (!title || !description || !startDate || !category) {
    throw createError('Título, descripción, fecha de inicio y categoría son requeridos', 400);
  }
  
  const slug = generateSlug(title);
  
  const existingEvento = await prisma.event.findUnique({
    where: { slug }
  });
  
  if (existingEvento) {
    throw createError('Ya existe un evento con este título', 409);
  }
  
  const evento = await prisma.event.create({
    data: {
      title: sanitizeText(title),
      slug,
      description: sanitizeText(description),
      content: content ? sanitizeText(content) : null,
      startDate: new Date(startDate),
      endDate: endDate ? new Date(endDate) : null,
      location: location ? sanitizeText(location) : null,
      image: image || null,
      category,
      isRecurring: Boolean(isRecurring),
      organizerId: req.user.id
    },
    include: {
      organizer: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
  
  logger.info(`Nuevo evento creado: ${evento.title} por ${req.user.name}`);
  
  res.status(201).json({
    success: true,
    data: { evento },
    message: 'Evento creado exitosamente'
  });
});