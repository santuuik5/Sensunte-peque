import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { sanitizeText, generateSlug } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/lugares:
 *   get:
 *     tags: [Lugares]
 *     summary: Obtener lugares turísticos de Sensuntepeque
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *           enum: [HISTORICO, RELIGIOSO, NATURAL, CULTURAL, MIRADOR, PLAZA, MUSEO, RESTAURANTE, HOTEL]
 *       - in: query
 *         name: active
 *         schema:
 *           type: boolean
 *         description: Solo lugares activos
 *     responses:
 *       200:
 *         description: Lista de lugares
 */
export const getLugares = asyncHandler(async (req: Request, res: Response) => {
  const { category, active } = req.query;
  
  const where: any = {
    isPublic: true
  };
  
  if (category) where.category = category;
  if (active !== 'false') where.isActive = true;
  
  const lugares = await prisma.place.findMany({
    where,
    orderBy: [
      { name: 'asc' }
    ],
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      address: true,
      latitude: true,
      longitude: true,
      category: true,
      image: true,
      gallery: true,
      isPublic: true,
      isActive: true,
      openingHours: true,
      contact: true,
      website: true,
      _count: {
        select: {
          photos: true
        }
      }
    }
  });
  
  // Agrupar por categoría
  const grouped = lugares.reduce((acc, lugar) => {
    if (!acc[lugar.category]) {
      acc[lugar.category] = [];
    }
    acc[lugar.category].push(lugar);
    return acc;
  }, {} as Record<string, typeof lugares>);
  
  res.json({
    success: true,
    data: {
      lugares,
      grouped,
      total: lugares.length,
      conFotos: lugares.filter(l => l._count.photos > 0).length
    },
    message: 'Lugares obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/lugares/{slug}:
 *   get:
 *     tags: [Lugares]
 *     summary: Obtener lugar por slug
 */
export const getLugarBySlug = asyncHandler(async (req: Request, res: Response) => {
  const { slug } = req.params;
  
  const lugar = await prisma.place.findFirst({
    where: {
      slug,
      isPublic: true,
      isActive: true
    },
    include: {
      photos: {
        select: {
          id: true,
          title: true,
          url: true,
          altText: true
        }
      }
    }
  });
  
  if (!lugar) {
    throw createError('Lugar no encontrado', 404);
  }
  
  // Lugares relacionados (misma categoría)
  const relacionados = await prisma.place.findMany({
    where: {
      category: lugar.category,
      isPublic: true,
      isActive: true,
      id: { not: lugar.id }
    },
    take: 3,
    orderBy: {
      name: 'asc'
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      image: true,
      category: true
    }
  });
  
  res.json({
    success: true,
    data: {
      lugar,
      relacionados
    },
    message: 'Lugar obtenido exitosamente'
  });
});

/**
 * @swagger
 * /api/lugares/emblematicos:
 *   get:
 *     tags: [Lugares]
 *     summary: Obtener lugares emblemáticos de Sensuntepeque
 */
export const getLugaresEmblematicos = asyncHandler(async (req: Request, res: Response) => {
  // Lugares emblemáticos basados en la investigación
  const lugaresEmblematicos = [
    {
      name: 'Iglesia Parroquial Santa Bárbara',
      description: 'Iglesia principal de Sensuntepeque, dedicada a Santa Bárbara, patrona de la ciudad. Centro de las celebraciones religiosas y punto de referencia histórico.',
      address: 'Plaza Central, Sensuntepeque',
      category: 'RELIGIOSO',
      coordenadas: {
        latitude: 13.876152777778,
        longitude: -88.628494444444
      },
      horarios: 'Misas: 6:00 AM, 12:00 PM, 6:00 PM',
      importancia: 'Patrimonio religioso principal',
      eventos: ['Fiestas Patronales', 'Corrida del Ángel', 'Las Recordadas'],
      arquitectura: 'Colonial con modificaciones modernas'
    },
    {
      name: 'Plaza Central',
      description: 'Corazón de la ciudad con su kiosco característico. Punto de encuentro y escenario de festividades comunitarias.',
      address: 'Centro de Sensuntepeque',
      category: 'PLAZA',
      caracteristicas: [
        'Kiosco central',
        'Bancas y árboles',
        'Área de eventos',
        'Comercio alrededor'
      ],
      actividades: 'Eventos culturales, mercados, reuniones comunitarias'
    },
    {
      name: 'Parque Luciano Hernández',
      description: 'Parque municipal con áreas verdes y espacios recreativos para familias.',
      address: 'Sensuntepeque',
      category: 'NATURAL',
      servicios: ['Juegos infantiles', 'Áreas verdes', 'Senderos', 'Bancas']
    },
    {
      name: 'Parque Cabañas',
      description: 'Espacio público con vista panorámica de la ciudad y los cerros circundantes.',
      address: 'Sensuntepeque',
      category: 'MIRADOR',
      caracteristicas: ['Vistas panorámicas', 'Miradores', 'Área de descanso']
    },
    {
      name: 'Iglesia El Calvario',
      description: 'Segunda iglesia importante de la ciudad, destino de la tradicional "Corrida del Ángel" durante Semana Santa.',
      address: 'Sensuntepeque',
      category: 'RELIGIOSO',
      tradicion: 'Corrida del Ángel (Domingo de Resurrección)',
      evento: 'Procesión de Los Farolitos'
    },
    {
      name: 'Los 400 Cerros - Miradores',
      description: 'Sistema de cerros que rodean Sensuntepeque, ofreciendo múltiples miradores naturales con vistas espectaculares.',
      address: 'Alrededores de Sensuntepeque',
      category: 'NATURAL',
      altitud: '820+ metros sobre el nivel del mar',
      actividades: [
        'Senderismo',
        'Observación de paisajes',
        'Fotografía',
        'Ecoturismo'
      ],
      acceso: 'Varios puntos de acceso desde la ciudad'
    },
    {
      name: 'Mercado Municipal',
      description: 'Centro de comercio local donde se pueden encontrar productos frescos, artesanías y comida tradicional.',
      address: 'Centro de Sensuntepeque',
      category: 'CULTURAL',
      productos: [
        'Frutas y verduras locales',
        'Comida tradicional',
        'Café de Cabañas',
        'Artesanías regionales'
      ],
      horarios: 'Lunes a domingo, desde muy temprano'
    },
    {
      name: 'Río Lempa - Zona Recreativa',
      description: 'Zona del río Lempa cercana a Sensuntepeque, donde se desarrolla pesca artesanal y actividades recreativas.',
      address: 'Cantón San Nicolás, Sensuntepeque',
      category: 'NATURAL',
      actividades: [
        'Pesca artesanal',
        'Recreación familiar',
        'Observación de naturaleza'
      ],
      importancia: 'Central hidroeléctrica 5 de noviembre'
    }
  ];
  
  res.json({
    success: true,
    data: {
      lugares: lugaresEmblematicos,
      total: lugaresEmblematicos.length,
      info: {
        ciudad: 'Sensuntepeque',
        apodo: 'Ciudad de los 400 cerros',
        altitud: '820 metros sobre el nivel del mar',
        coordenadas: {
          latitud: 13.876152777778,
          longitud: -88.628494444444
        },
        distanciaCapital: '83 km al noreste de San Salvador'
      }
    },
    message: 'Lugares emblemáticos de Sensuntepeque obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/lugares:
 *   post:
 *     tags: [Lugares]
 *     summary: Crear nuevo lugar (Admin)
 */
export const createLugar = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const {
    name,
    description,
    address,
    latitude,
    longitude,
    category,
    image,
    gallery = [],
    openingHours,
    contact,
    website
  } = req.body;
  
  if (!name || !description || !category) {
    throw createError('Nombre, descripción y categoría son requeridos', 400);
  }
  
  const slug = generateSlug(name);
  
  const existingLugar = await prisma.place.findUnique({
    where: { slug }
  });
  
  if (existingLugar) {
    throw createError('Ya existe un lugar con este nombre', 409);
  }
  
  const lugar = await prisma.place.create({
    data: {
      name: sanitizeText(name),
      slug,
      description: sanitizeText(description),
      address: address ? sanitizeText(address) : null,
      latitude: latitude ? parseFloat(latitude) : null,
      longitude: longitude ? parseFloat(longitude) : null,
      category,
      image: image || null,
      gallery: Array.isArray(gallery) ? gallery : [],
      openingHours: openingHours ? sanitizeText(openingHours) : null,
      contact: contact ? sanitizeText(contact) : null,
      website: website || null
    }
  });
  
  logger.info(`Nuevo lugar creado: ${lugar.name} por ${req.user.name}`);
  
  res.status(201).json({
    success: true,
    data: { lugar },
    message: 'Lugar creado exitosamente'
  });
});