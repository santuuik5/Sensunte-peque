import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { sanitizeText, generateSlug } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/historia:
 *   get:
 *     tags: [Historia]
 *     summary: Obtener artículos históricos de Sensuntepeque
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *         description: Número de página
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 50
 *         description: Artículos por página
 *       - in: query
 *         name: featured
 *         schema:
 *           type: boolean
 *         description: Solo artículos destacados
 *     responses:
 *       200:
 *         description: Lista de artículos históricos
 */
export const getHistoriaArticles = asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 10, 50);
  const featured = req.query.featured === 'true';
  const skip = (page - 1) * limit;
  
  const where = {
    category: 'HISTORIA' as const,
    isPublished: true,
    ...(featured && { isFeatured: true })
  };
  
  const [articles, total] = await Promise.all([
    prisma.article.findMany({
      where,
      skip,
      take: limit,
      orderBy: [
        { isFeatured: 'desc' },
        { publishedAt: 'desc' },
        { createdAt: 'desc' }
      ],
      select: {
        id: true,
        title: true,
        slug: true,
        excerpt: true,
        coverImage: true,
        category: true,
        isFeatured: true,
        viewCount: true,
        publishedAt: true,
        author: {
          select: {
            id: true,
            name: true
          }
        },
        tags: {
          select: {
            tag: {
              select: {
                id: true,
                name: true,
                slug: true,
                color: true
              }
            }
          }
        },
        _count: {
          select: {
            comments: true
          }
        }
      }
    }),
    prisma.article.count({ where })
  ]);
  
  const totalPages = Math.ceil(total / limit);
  
  res.json({
    success: true,
    data: {
      articles: articles.map(article => ({
        ...article,
        tags: article.tags.map(t => t.tag),
        commentCount: article._count.comments
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    },
    message: 'Artículos históricos obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/historia/{slug}:
 *   get:
 *     tags: [Historia]
 *     summary: Obtener artículo histórico por slug
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *         description: Slug del artículo
 *     responses:
 *       200:
 *         description: Artículo histórico
 *       404:
 *         description: Artículo no encontrado
 */
export const getHistoriaBySlug = asyncHandler(async (req: Request, res: Response) => {
  const { slug } = req.params;
  
  const article = await prisma.article.findFirst({
    where: {
      slug,
      category: 'HISTORIA',
      isPublished: true
    },
    select: {
      id: true,
      title: true,
      slug: true,
      content: true,
      excerpt: true,
      coverImage: true,
      category: true,
      isFeatured: true,
      viewCount: true,
      publishedAt: true,
      updatedAt: true,
      author: {
        select: {
          id: true,
          name: true
        }
      },
      tags: {
        select: {
          tag: {
            select: {
              id: true,
              name: true,
              slug: true,
              color: true
            }
          }
        }
      },
      photos: {
        select: {
          id: true,
          title: true,
          url: true,
          altText: true
        },
        orderBy: {
          createdAt: 'asc'
        }
      },
      comments: {
        where: {
          isPublic: true
        },
        select: {
          id: true,
          content: true,
          createdAt: true,
          author: {
            select: {
              id: true,
              name: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      }
    }
  });
  
  if (!article) {
    throw createError('Artículo histórico no encontrado', 404);
  }
  
  // Incrementar contador de vistas
  await prisma.article.update({
    where: { id: article.id },
    data: {
      viewCount: {
        increment: 1
      }
    }
  });
  
  // Obtener artículos relacionados
  const relatedArticles = await prisma.article.findMany({
    where: {
      category: 'HISTORIA',
      isPublished: true,
      id: {
        not: article.id
      }
    },
    take: 3,
    orderBy: {
      publishedAt: 'desc'
    },
    select: {
      id: true,
      title: true,
      slug: true,
      excerpt: true,
      coverImage: true,
      publishedAt: true
    }
  });
  
  res.json({
    success: true,
    data: {
      article: {
        ...article,
        tags: article.tags.map(t => t.tag)
      },
      relatedArticles
    },
    message: 'Artículo histórico obtenido exitosamente'
  });
});

/**
 * @swagger
 * /api/historia:
 *   post:
 *     tags: [Historia]
 *     summary: Crear nuevo artículo histórico (Admin)
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               content:
 *                 type: string
 *               excerpt:
 *                 type: string
 *               coverImage:
 *                 type: string
 *               isFeatured:
 *                 type: boolean
 *               tags:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Artículo creado exitosamente
 *       401:
 *         description: No autorizado
 *       403:
 *         description: Permisos insuficientes
 */
export const createHistoriaArticle = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const { title, content, excerpt, coverImage, isFeatured = false, tags = [] } = req.body;
  
  if (!title || !content) {
    throw createError('Título y contenido son requeridos', 400);
  }
  
  const slug = generateSlug(title);
  
  // Verificar que el slug sea único
  const existingArticle = await prisma.article.findUnique({
    where: { slug }
  });
  
  if (existingArticle) {
    throw createError('Ya existe un artículo con este título', 409);
  }
  
  // Crear artículo
  const article = await prisma.article.create({
    data: {
      title: sanitizeText(title),
      slug,
      content: sanitizeText(content),
      excerpt: excerpt ? sanitizeText(excerpt) : null,
      coverImage: coverImage || null,
      category: 'HISTORIA',
      isFeatured: Boolean(isFeatured),
      isPublished: true,
      publishedAt: new Date(),
      authorId: req.user.id
    },
    select: {
      id: true,
      title: true,
      slug: true,
      excerpt: true,
      coverImage: true,
      category: true,
      isFeatured: true,
      isPublished: true,
      publishedAt: true,
      author: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
  
  // Agregar tags si se proporcionaron
  if (tags.length > 0) {
    const tagConnections = [];
    
    for (const tagName of tags) {
      const tagSlug = generateSlug(tagName);
      
      // Crear o encontrar tag
      const tag = await prisma.tag.upsert({
        where: { slug: tagSlug },
        update: {},
        create: {
          name: sanitizeText(tagName),
          slug: tagSlug
        }
      });
      
      tagConnections.push({
        articleId: article.id,
        tagId: tag.id
      });
    }
    
    await prisma.articleTag.createMany({
      data: tagConnections,
      skipDuplicates: true
    });
  }
  
  logger.info(`Artículo histórico creado: ${article.title} por ${req.user.name}`);
  
  res.status(201).json({
    success: true,
    data: { article },
    message: 'Artículo histórico creado exitosamente'
  });
});