import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { sanitizeText, generateSlug } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/gastronomia:
 *   get:
 *     tags: [Gastronomía]
 *     summary: Obtener platos típicos de Sensuntepeque
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *           enum: [DESAYUNOS, ALMUERZOS, CENAS, POSTRES, BEBIDAS, ANTOJITOS, FESTIVALES]
 *         description: Categoría de plato
 *       - in: query
 *         name: difficulty
 *         schema:
 *           type: string
 *           enum: [FACIL, INTERMEDIO, DIFICIL]
 *         description: Dificultad de preparación
 *       - in: query
 *         name: traditional
 *         schema:
 *           type: boolean
 *         description: Solo platos tradicionales
 *     responses:
 *       200:
 *         description: Lista de platos
 */
export const getPlatos = asyncHandler(async (req: Request, res: Response) => {
  const { category, difficulty, traditional } = req.query;
  
  const where: any = {
    isPublished: true
  };
  
  if (category) where.category = category;
  if (difficulty) where.difficulty = difficulty;
  if (traditional === 'true') where.isTraditional = true;
  
  const platos = await prisma.dish.findMany({
    where,
    orderBy: [
      { isTraditional: 'desc' },
      { name: 'asc' }
    ],
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      image: true,
      category: true,
      isTraditional: true,
      difficulty: true,
      prepTime: true,
      servings: true,
      createdAt: true
    }
  });
  
  // Agrupar por categoría
  const grouped = platos.reduce((acc, plato) => {
    if (!acc[plato.category]) {
      acc[plato.category] = [];
    }
    acc[plato.category].push(plato);
    return acc;
  }, {} as Record<string, typeof platos>);
  
  res.json({
    success: true,
    data: {
      platos,
      grouped,
      total: platos.length,
      stats: {
        tradicionales: platos.filter(p => p.isTraditional).length,
        modernos: platos.filter(p => !p.isTraditional).length
      }
    },
    message: 'Platos obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/gastronomia/{slug}:
 *   get:
 *     tags: [Gastronomía]
 *     summary: Obtener plato por slug
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Plato encontrado
 *       404:
 *         description: Plato no encontrado
 */
export const getPlatoBySlug = asyncHandler(async (req: Request, res: Response) => {
  const { slug } = req.params;
  
  const plato = await prisma.dish.findFirst({
    where: {
      slug,
      isPublished: true
    }
  });
  
  if (!plato) {
    throw createError('Plato no encontrado', 404);
  }
  
  // Obtener platos relacionados (misma categoría)
  const relacionados = await prisma.dish.findMany({
    where: {
      category: plato.category,
      isPublished: true,
      id: { not: plato.id }
    },
    take: 3,
    orderBy: {
      name: 'asc'
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      image: true,
      difficulty: true,
      prepTime: true
    }
  });
  
  res.json({
    success: true,
    data: {
      plato,
      relacionados
    },
    message: 'Plato obtenido exitosamente'
  });
});

/**
 * @swagger
 * /api/gastronomia/tipicos:
 *   get:
 *     tags: [Gastronomía]
 *     summary: Obtener platos típicos más famosos de Sensuntepeque
 *     responses:
 *       200:
 *         description: Platos típicos famosos
 */
export const getPlatosTipicos = asyncHandler(async (req: Request, res: Response) => {
  // Platos típicos específicos de Sensuntepeque basados en la investigación
  const platosTipicos = [
    {
      name: 'Riguas con Leche Cruda',
      description: 'Tortilla hecha de una mezcla de maíz, queso y crema, servida en un plato de leche recién ordeñada. Una delicia única de Sensuntepeque.',
      category: 'ANTOJITOS',
      difficulty: 'FACIL',
      prepTime: 30,
      servings: 4,
      ingredients: [
        'Maíz tierno molido',
        'Queso fresco rallado',
        'Crema ácida',
        'Leche cruda recién ordeñada',
        'Sal al gusto'
      ],
      isTraditional: true,
      origen: 'Sensuntepeque, Cabañas'
    },
    {
      name: 'Atol Shuco',
      description: 'Bebida tradicional caliente distribuida en las madrugadas durante las fiestas patronales de Santa Bárbara.',
      category: 'BEBIDAS',
      difficulty: 'INTERMEDIO',
      prepTime: 45,
      servings: 8,
      ingredients: [
        'Maíz morado',
        'Frijoles negros',
        'Chiltepe',
        'Hierba buena',
        'Sal',
        'Especias locales'
      ],
      isTraditional: true,
      ocasion: 'Fiestas patronales'
    },
    {
      name: 'Pupusas de Sensuntepeque',
      description: 'Las tradicionales pupusas salvadoreñas con el toque especial de los cocineros sensuntepecanos.',
      category: 'ALMUERZOS',
      difficulty: 'INTERMEDIO',
      prepTime: 60,
      servings: 6,
      ingredients: [
        'Masa de maíz',
        'Queso fresco local',
        'Frijoles refritos',
        'Chicharón',
        'Curtido',
        'Salsa de tomate'
      ],
      isTraditional: true,
      popularidad: 'Alta'
    },
    {
      name: 'Tamales Sensuntepecanos',
      description: 'Tamales tradicionales con recetas familiares transmitidas por generaciones en la región.',
      category: 'FESTIVALES',
      difficulty: 'DIFICIL',
      prepTime: 180,
      servings: 12,
      ingredients: [
        'Masa de maíz',
        'Carne de cerdo',
        'Pollo',
        'Tomate',
        'Chile dulce',
        'Hojas de plátano',
        'Especias tradicionales'
      ],
      isTraditional: true,
      ocasion: 'Fiestas familiares'
    },
    {
      name: 'Café de Cabañas',
      description: 'Café de altura cultivado en las montañas alrededor de Sensuntepeque, conocido por su sabor único.',
      category: 'BEBIDAS',
      difficulty: 'FACIL',
      prepTime: 10,
      servings: 1,
      ingredients: [
        'Granos de café de altura',
        'Agua pura de manantial',
        'Azúcar morena (opcional)'
      ],
      isTraditional: true,
      caracteristica: 'Producto local de exportación'
    }
  ];
  
  res.json({
    success: true,
    data: {
      platos: platosTipicos,
      total: platosTipicos.length,
      info: {
        region: 'Sensuntepeque, Cabañas',
        altitud: '820 metros sobre el nivel del mar',
        clima: 'Templado, ideal para cultivos diversos',
        especialidad: 'Riguas con leche cruda y café de altura'
      }
    },
    message: 'Platos típicos de Sensuntepeque obtenidos exitosamente'
  });
});

/**
 * @swagger
 * /api/gastronomia:
 *   post:
 *     tags: [Gastronomía]
 *     summary: Crear nuevo plato (Admin)
 *     security:
 *       - bearerAuth: []
 */
export const createPlato = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const {
    name,
    description,
    recipe,
    ingredients = [],
    image,
    category,
    isTraditional = true,
    difficulty = 'FACIL',
    prepTime,
    servings
  } = req.body;
  
  if (!name || !description || !category) {
    throw createError('Nombre, descripción y categoría son requeridos', 400);
  }
  
  const slug = generateSlug(name);
  
  // Verificar que el slug sea único
  const existingPlato = await prisma.dish.findUnique({
    where: { slug }
  });
  
  if (existingPlato) {
    throw createError('Ya existe un plato con este nombre', 409);
  }
  
  const plato = await prisma.dish.create({
    data: {
      name: sanitizeText(name),
      slug,
      description: sanitizeText(description),
      recipe: recipe ? sanitizeText(recipe) : null,
      ingredients: Array.isArray(ingredients) ? ingredients.map(sanitizeText) : [],
      image: image || null,
      category,
      isTraditional: Boolean(isTraditional),
      difficulty,
      prepTime: prepTime ? parseInt(prepTime) : null,
      servings: servings ? parseInt(servings) : null
    }
  });
  
  logger.info(`Nuevo plato creado: ${plato.name} por ${req.user.name}`);
  
  res.status(201).json({
    success: true,
    data: { plato },
    message: 'Plato creado exitosamente'
  });
});