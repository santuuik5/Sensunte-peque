import { Request, Response } from 'express';
import { prisma } from '../database/connection';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { sanitizeText, generateSlug } from '../middleware/validation';
import { logger } from '../utils/logger';

/**
 * @swagger
 * /api/tradiciones:
 *   get:
 *     tags: [Tradiciones]
 *     summary: Obtener tradiciones de Sensuntepeque
 *     parameters:
 *       - in: query
 *         name: month
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 12
 *         description: Filtrar por mes
 *       - in: query
 *         name: active
 *         schema:
 *           type: boolean
 *         description: Solo tradiciones activas
 *     responses:
 *       200:
 *         description: Lista de tradiciones
 */
export const getTradiciones = asyncHandler(async (req: Request, res: Response) => {
  const month = req.query.month ? parseInt(req.query.month as string) : undefined;
  const activeOnly = req.query.active !== 'false';
  
  const where = {
    ...(activeOnly && { isActive: true }),
    ...(month && { month })
  };
  
  const tradiciones = await prisma.tradition.findMany({
    where,
    orderBy: [
      { month: 'asc' },
      { name: 'asc' }
    ],
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      date: true,
      month: true,
      image: true,
      gallery: true,
      isActive: true,
      createdAt: true,
      updatedAt: true
    }
  });
  
  // Agrupar por mes si no se especificó un mes en particular
  let groupedData;
  
  if (!month) {
    groupedData = tradiciones.reduce((acc, tradicion) => {
      const monthKey = tradicion.month || 0;
      if (!acc[monthKey]) {
        acc[monthKey] = [];
      }
      acc[monthKey].push(tradicion);
      return acc;
    }, {} as Record<number, typeof tradiciones>);
  }
  
  res.json({
    success: true,
    data: {
      tradiciones,
      ...(groupedData && { agrupadas: groupedData }),
      total: tradiciones.length
    },
    message: 'Tradiciones obtenidas exitosamente'
  });
});

/**
 * @swagger
 * /api/tradiciones/{slug}:
 *   get:
 *     tags: [Tradiciones]
 *     summary: Obtener tradición por slug
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *         description: Slug de la tradición
 *     responses:
 *       200:
 *         description: Tradición encontrada
 *       404:
 *         description: Tradición no encontrada
 */
export const getTradicionBySlug = asyncHandler(async (req: Request, res: Response) => {
  const { slug } = req.params;
  
  const tradicion = await prisma.tradition.findFirst({
    where: {
      slug,
      isActive: true
    }
  });
  
  if (!tradicion) {
    throw createError('Tradición no encontrada', 404);
  }
  
  // Obtener tradiciones relacionadas (del mismo mes o similares)
  const relacionadas = await prisma.tradition.findMany({
    where: {
      isActive: true,
      id: { not: tradicion.id },
      OR: [
        { month: tradicion.month },
        { month: null } // Tradiciones sin mes específico
      ]
    },
    take: 3,
    orderBy: {
      name: 'asc'
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      date: true,
      image: true
    }
  });
  
  res.json({
    success: true,
    data: {
      tradicion,
      relacionadas
    },
    message: 'Tradición obtenida exitosamente'
  });
});

/**
 * @swagger
 * /api/tradiciones:
 *   post:
 *     tags: [Tradiciones]
 *     summary: Crear nueva tradición (Admin)
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *               content:
 *                 type: string
 *               date:
 *                 type: string
 *               month:
 *                 type: integer
 *               image:
 *                 type: string
 *               gallery:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Tradición creada exitosamente
 */
export const createTradicion = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    throw createError('Usuario no autenticado', 401);
  }
  
  const { name, description, content, date, month, image, gallery = [] } = req.body;
  
  if (!name || !description) {
    throw createError('Nombre y descripción son requeridos', 400);
  }
  
  const slug = generateSlug(name);
  
  // Verificar que el slug sea único
  const existingTradicion = await prisma.tradition.findUnique({
    where: { slug }
  });
  
  if (existingTradicion) {
    throw createError('Ya existe una tradición con este nombre', 409);
  }
  
  const tradicion = await prisma.tradition.create({
    data: {
      name: sanitizeText(name),
      slug,
      description: sanitizeText(description),
      content: content ? sanitizeText(content) : null,
      date: date || null,
      month: month || null,
      image: image || null,
      gallery: Array.isArray(gallery) ? gallery : []
    }
  });
  
  logger.info(`Nueva tradición creada: ${tradicion.name} por ${req.user.name}`);
  
  res.status(201).json({
    success: true,
    data: { tradicion },
    message: 'Tradición creada exitosamente'
  });
});

/**
 * @swagger
 * /api/tradiciones/famosas:
 *   get:
 *     tags: [Tradiciones]
 *     summary: Obtener las tradiciones más famosas de Sensuntepeque
 *     responses:
 *       200:
 *         description: Tradiciones famosas
 */
export const getTradicionesFamosas = asyncHandler(async (req: Request, res: Response) => {
  // Lista de tradiciones específicas de Sensuntepeque basadas en la investigación
  const tradicionesFamosas = [
    {
      name: 'Los Fogones',
      description: 'Cada 7 de diciembre las personas recolectan hojas y las queman en la cuneta a las seis de la tarde, celebrando la víspera de la Virgen de Concepción.',
      date: '7 de diciembre',
      month: 12,
      categoria: 'religiosa'
    },
    {
      name: 'Las Recordadas',
      description: 'Especie de serenatas dadas a las cinco de la mañana en honor a Santa Bárbara, durante toda la duración de las fiestas patronales.',
      date: 'Fiestas patronales (24 nov - 5 dic)',
      month: 11,
      categoria: 'musical'
    },
    {
      name: 'La Corrida del Ángel',
      description: 'Cada domingo de resurrección a las cuatro de la madrugada sale de la iglesia Santa Bárbara una imagen de ángel que es llevada corriendo hasta la iglesia El Calvario.',
      date: 'Domingo de Resurrección',
      month: null,
      categoria: 'religiosa'
    },
    {
      name: 'Riguas con Leche Cruda',
      description: 'Tradición de servir riguas (tortilla de maíz, queso y crema) introducidas en un plato de leche recién ordeñada.',
      date: 'Todo el año',
      month: null,
      categoria: 'gastronomica'
    },
    {
      name: 'Alfombras de Aserrín',
      description: 'Elaboración de alfombras y tapices de aserrín y sal teñida durante la Semana Santa para las procesiones.',
      date: 'Semana Santa',
      month: null,
      categoria: 'artistica'
    }
  ];
  
  res.json({
    success: true,
    data: {
      tradiciones: tradicionesFamosas,
      total: tradicionesFamosas.length,
      info: {
        ciudad: 'Sensuntepeque',
        departamento: 'Cabañas',
        descripcion: 'Conocida como "la ciudad de los 400 cerros"'
      }
    },
    message: 'Tradiciones famosas de Sensuntepeque obtenidas exitosamente'
  });
});