-- Inicialización de la base de datos para Sensuntepeque Cultural

-- Crear extensiones si es necesario
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Configurar timezone
SET timezone = 'America/El_Salvador';

-- Comentarios sobre la base de datos
COMMENT ON DATABASE sensuntepeque_db IS 'Base de datos para la aplicación cultural de Sensuntepeque, El Salvador';

-- Crear índices adicionales para optimizar búsquedas
-- (Estos se crearán después de que Prisma cree las tablas)

-- Configuraciones adicionales
-- Permitir búsquedas de texto completo en español
CREATE TEXT SEARCH CONFIGURATION spanish_config (COPY = spanish);

-- Configurar memoria compartida para mejor rendimiento
-- (Esto debería configurarse en postgresql.conf en producción)
SET shared_preload_libraries = 'pg_stat_statements';

-- Mensaje de bienvenida
DO $$
BEGIN
    RAISE NOTICE 'Base de datos para Sensuntepeque Cultural inicializada correctamente';
    RAISE NOTICE 'Ubicación: Sensuntepeque, Cabañas, El Salvador';
    RAISE NOTICE 'Conocida como: La ciudad de los 400 cerros';
END $$;