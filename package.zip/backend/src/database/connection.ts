import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  errorFormat: 'minimal'
});

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

// Función para conectar y verificar la base de datos
export async function connectDatabase() {
  try {
    await prisma.$connect();
    logger.info('🔗 Conexión a PostgreSQL establecida');
    
    // Verificar conectividad
    await prisma.$queryRaw`SELECT 1`;
    logger.info('✅ Verificación de base de datos exitosa');
    
  } catch (error) {
    logger.error('❌ Error conectando a la base de datos:', error);
    throw error;
  }
}

// Función para desconectar de la base de datos
export async function disconnectDatabase() {
  try {
    await prisma.$disconnect();
    logger.info('🔌 Desconexión de base de datos exitosa');
  } catch (error) {
    logger.error('❌ Error desconectando de la base de datos:', error);
  }
}

// Función para verificar el estado de la base de datos
export async function checkDatabaseHealth() {
  try {
    const start = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    const end = Date.now();
    
    return {
      status: 'healthy',
      responseTime: `${end - start}ms`,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    };
  }
}

export default prisma;