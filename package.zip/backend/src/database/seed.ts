import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../utils/auth';
import { logger } from '../utils/logger';

const prisma = new PrismaClient();

async function main() {
  logger.info('🌱 Iniciando proceso de seeding...');

  try {
    // Crear usuario administrador
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@sensuntepeque.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123456';
    
    const hashedPassword = await hashPassword(adminPassword);
    
    const admin = await prisma.user.upsert({
      where: { email: adminEmail },
      update: {},
      create: {
        name: 'Administrador',
        email: adminEmail,
        password: hashedPassword,
        role: 'ADMIN',
        isActive: true
      }
    });
    
    logger.info(`✅ Usuario administrador creado: ${admin.email}`);

    // Crear tags principales
    const tags = [
      { name: 'Historia', slug: 'historia', color: '#8B5A3C' },
      { name: 'Tradiciones', slug: 'tradiciones', color: '#D97706' },
      { name: 'Gastronomía', slug: 'gastronomia', color: '#DC2626' },
      { name: 'Fiestas Patronales', slug: 'fiestas-patronales', color: '#7C3AED' },
      { name: 'Santa Bárbara', slug: 'santa-barbara', color: '#059669' },
      { name: 'Los 400 Cerros', slug: 'los-400-cerros', color: '#0891B2' },
      { name: 'Riguas', slug: 'riguas', color: '#EA580C' },
      { name: 'Atol Shuco', slug: 'atol-shuco', color: '#7C2D12' },
      { name: 'Pupusas', slug: 'pupusas', color: '#BE123C' },
      { name: 'Café de Cabañas', slug: 'cafe-de-cabanas', color: '#92400E' }
    ];

    for (const tag of tags) {
      await prisma.tag.upsert({
        where: { slug: tag.slug },
        update: { color: tag.color },
        create: tag
      });
    }
    
    logger.info(`✅ ${tags.length} tags creados`);

    // Crear artículo de historia principal
    const historiaArticle = await prisma.article.upsert({
      where: { slug: 'historia-de-sensuntepeque' },
      update: {},
      create: {
        title: 'Historia de Sensuntepeque: La Ciudad de los 400 Cerros',
        slug: 'historia-de-sensuntepeque',
        content: `# Historia de Sensuntepeque

Sensuntepeque, cuyo nombre proviene del náhuatl "Centzuntepec", significa "Cerro Grande" o "Ciudad de los 400 Cerros". Esta hermosa ciudad, cabecera del departamento de Cabañas, tiene raíces que se remontan a la época precolombina.

## Orígenes Precolombinos

La región fue habitada originalmente por pueblos lencas, pero posteriormente fue influenciada por guerreros yaquis o pipiles que incursionaron en la zona y le dieron el nombre que conserva hasta hoy.

## Fundación Colonial

Sensuntepeque fue fundada oficialmente por los Pipiles en el año 1550. En 1799 se convirtió en cabecera del partido de Titihuapa, consolidando su importancia regional.

## Independencia y Desarrollo

El 20 de diciembre de 1811, los pobladores de Sensuntepeque se alzaron contra el dominio colonial español, demostrando su espíritu libertario.

Tras la independencia en 1821, la ciudad recibió el título de villa durante el gobierno de José María Cornejo (1829-1832). Posteriormente, el 4 de febrero de 1865, el presidente Francisco Dueñas le confirió el título de ciudad, reconociendo su población, riqueza, ornato y cultura.

## Patrimonio y Tradiciones

Hoy, Sensuntepeque conserva un rico patrimonio cultural que incluye:

- La Iglesia Parroquial Santa Bárbara
- Tradiciones únicas como "Los Fogones" y "Las Recordadas"
- Una gastronomía distintiva con platos como las riguas con leche cruda
- Festivales y celebraciones que mantienen vivas las costumbres ancestrales

Con una población de 35,916 habitantes y ubicada a 820 metros sobre el nivel del mar, Sensuntepeque sigue siendo un testimonio vivo de la historia salvadoreña, donde el pasado y el presente se entrelazan en perfecta armonía.`,
        excerpt: 'Descubre la fascinante historia de Sensuntepeque, desde sus orígenes precolombinos hasta convertirse en la vibrante "Ciudad de los 400 Cerros" que conocemos hoy.',
        category: 'HISTORIA',
        isFeatured: true,
        isPublished: true,
        publishedAt: new Date(),
        authorId: admin.id
      }
    });

    logger.info('✅ Artículo de historia principal creado');

    // Crear tradiciones principales
    const tradiciones = [
      {
        name: 'Los Fogones',
        slug: 'los-fogones',
        description: 'Cada 7 de diciembre las personas recolectan hojas y las queman en la cuneta a las seis de la tarde, celebrando la víspera de la Virgen de Concepción.',
        content: `# Los Fogones: Tradición Luminos de Sensuntepeque

Los Fogones representan una de las tradiciones más hermosas y únicas de Sensuntepeque. Cada 7 de diciembre, al atardecer, toda la ciudad se ilumina con pequeños fuegos que crean una atmósfera mágica.

## Cómo se Celebra

La tradición comienza en la mañana cuando las familias, especialmente los niños, salen a recolectar hojas secas por toda la ciudad. Al llegar las seis de la tarde, estas hojas se queman simultáneamente en las cunetas de las calles.

## Significado Religioso

Esta celebración marca la víspera de la Inmaculada Concepción de María, mostrando la profunda fe católica del pueblo sensuntepecano.

## Un Espectáculo Único

Ver a toda la ciudad iluminada por cientos de pequeños fogones al mismo tiempo es una experiencia inolvidable que atrae visitantes de toda la región.`,
        date: '7 de diciembre',
        month: 12,
        isActive: true
      },
      {
        name: 'Las Recordadas',
        slug: 'las-recordadas',
        description: 'Especie de serenatas dadas a las cinco de la mañana en honor a Santa Bárbara, durante toda la duración de las fiestas patronales.',
        content: `# Las Recordadas: Serenatas del Amanecer

Las Recordadas son una tradición musical única de Sensuntepeque que se realiza durante las fiestas patronales en honor a Santa Bárbara.

## La Madrugada Musical

Cada mañana, a las cinco en punto, grupos de músicos recorren las calles de la ciudad interpretando canciones tradicionales y religiosas. Estas serenatas matutinas despiertan a los habitantes con melodías que honran a la patrona.

## Participación Comunitaria

Los vecinos salen de sus casas para escuchar y acompañar a los músicos, creando un ambiente de hermandad y devoción que fortalece los lazos comunitarios.

## Duración

Esta tradición se mantiene durante toda la duración de las fiestas patronales, del 24 de noviembre al 5 de diciembre.`,
        date: 'Fiestas patronales (24 nov - 5 dic)',
        month: 11,
        isActive: true
      },
      {
        name: 'La Corrida del Ángel',
        slug: 'la-corrida-del-angel',
        description: 'Cada domingo de resurrección a las cuatro de la madrugada sale de la iglesia Santa Bárbara una imagen de ángel que es llevada corriendo hasta la iglesia El Calvario.',
        content: `# La Corrida del Ángel: Tradición de Semana Santa

La Corrida del Ángel es una emotiva tradición de Semana Santa que simboliza el anuncio de la resurrección de Cristo.

## El Recorrido Sagrado

A las cuatro de la madrugada del Domingo de Resurrección, una imagen de ángel sale corriendo desde la iglesia Santa Bárbara hasta la iglesia El Calvario, donde se abren las puertas para que salgan las imágenes de las tres Marías.

## Simbolismo

Este recorrido representa el momento bíblico cuando el ángel anuncia a las mujeres que Cristo ha resucitado.

## Procesión de los Farolitos

Después de la corrida, todas las imágenes se reúnen para dar inicio a la hermosa "Procesión de los Farolitos", iluminando las calles de Sensuntepeque en la madrugada pascual.`,
        date: 'Domingo de Resurrección',
        month: null,
        isActive: true
      }
    ];

    for (const tradicion of tradiciones) {
      await prisma.tradition.upsert({
        where: { slug: tradicion.slug },
        update: {},
        create: tradicion
      });
    }

    logger.info(`✅ ${tradiciones.length} tradiciones creadas`);

    // Crear platos típicos
    const platos = [
      {
        name: 'Riguas con Leche Cruda',
        slug: 'riguas-con-leche-cruda',
        description: 'Tortilla hecha de una mezcla de maíz, queso y crema, servida en un plato de leche recién ordeñada. Una delicia única de Sensuntepeque.',
        recipe: `# Riguas con Leche Cruda

## Ingredientes:
- 2 tazas de maíz tierno molido
- 1 taza de queso fresco rallado
- 1/2 taza de crema ácida
- Sal al gusto
- 2 tazas de leche cruda recién ordeñada

## Preparación:
1. Mezclar el maíz molido con el queso y la crema
2. Agregar sal al gusto
3. Formar tortillas y cocinar en comal
4. Servir calientes en platos hondos
5. Bañar con leche cruda fría

¡Una experiencia gastronómica única de Sensuntepeque!`,
        ingredients: ['Maíz tierno molido', 'Queso fresco rallado', 'Crema ácida', 'Leche cruda recién ordeñada', 'Sal al gusto'],
        category: 'ANTOJITOS',
        isTraditional: true,
        difficulty: 'FACIL',
        prepTime: 30,
        servings: 4,
        isPublished: true
      },
      {
        name: 'Atol Shuco',
        slug: 'atol-shuco',
        description: 'Bebida tradicional caliente distribuida en las madrugadas durante las fiestas patronales de Santa Bárbara.',
        recipe: `# Atol Shuco Tradicional

## Ingredientes:
- 2 tazas de maíz morado
- 1 taza de frijoles negros
- Chiltepe al gusto
- Hierba buena
- Sal
- Especias locales

## Preparación:
1. Cocer el maíz y los frijoles por separado
2. Moler juntos hasta obtener una mezcla homogénea
3. Agregar especias y hierbas
4. Cocinar a fuego lento removiendo constantemente
5. Servir caliente en las madrugadas frías

Tradicionalmente se reparte gratis durante las fiestas patronales.`,
        ingredients: ['Maíz morado', 'Frijoles negros', 'Chiltepe', 'Hierba buena', 'Sal', 'Especias locales'],
        category: 'BEBIDAS',
        isTraditional: true,
        difficulty: 'INTERMEDIO',
        prepTime: 45,
        servings: 8,
        isPublished: true
      }
    ];

    for (const plato of platos) {
      await prisma.dish.upsert({
        where: { slug: plato.slug },
        update: {},
        create: plato
      });
    }

    logger.info(`✅ ${platos.length} platos tradicionales creados`);

    // Crear lugares emblemáticos
    const lugares = [
      {
        name: 'Iglesia Parroquial Santa Bárbara',
        slug: 'iglesia-santa-barbara',
        description: 'Iglesia principal de Sensuntepeque, dedicada a Santa Bárbara, patrona de la ciudad. Centro de las celebraciones religiosas y punto de referencia histórico.',
        address: 'Plaza Central, Sensuntepeque',
        latitude: 13.876152777778,
        longitude: -88.628494444444,
        category: 'RELIGIOSO',
        isPublic: true,
        isActive: true,
        openingHours: 'Misas: 6:00 AM, 12:00 PM, 6:00 PM'
      },
      {
        name: 'Plaza Central',
        slug: 'plaza-central',
        description: 'Corazón de la ciudad con su kiosco característico. Punto de encuentro y escenario de festividades comunitarias.',
        address: 'Centro de Sensuntepeque',
        latitude: 13.876152777778,
        longitude: -88.628494444444,
        category: 'PLAZA',
        isPublic: true,
        isActive: true
      },
      {
        name: 'Los 400 Cerros - Miradores',
        slug: 'los-400-cerros-miradores',
        description: 'Sistema de cerros que rodean Sensuntepeque, ofreciendo múltiples miradores naturales con vistas espectaculares.',
        address: 'Alrededores de Sensuntepeque',
        category: 'NATURAL',
        isPublic: true,
        isActive: true
      }
    ];

    for (const lugar of lugares) {
      await prisma.place.upsert({
        where: { slug: lugar.slug },
        update: {},
        create: lugar
      });
    }

    logger.info(`✅ ${lugares.length} lugares emblemáticos creados`);

    // Crear evento de fiestas patronales
    const evento = await prisma.event.upsert({
      where: { slug: 'fiestas-patronales-santa-barbara-2024' },
      update: {},
      create: {
        title: 'Fiestas Patronales de Santa Bárbara 2024',
        slug: 'fiestas-patronales-santa-barbara-2024',
        description: 'Las fiestas patronales más importantes de Sensuntepeque, con procesiones, ferias, música y comida tradicional.',
        content: `# Fiestas Patronales de Santa Bárbara 2024

Las fiestas patronales en honor a Santa Bárbara son la celebración más importante del año en Sensuntepeque.

## Programa de Actividades

### Actividades Religiosas
- Procesiones diarias
- Misas especiales
- Las "Recordadas" (serenatas matutinas)
- Novena a Santa Bárbara

### Actividades Culturales
- Conciertos musicales
- Bailes folclóricos
- Exposición de artesanías
- Festival gastronómico

### Actividades Recreativas
- Juegos mecánicos
- Feria del pueblo
- Concursos y rifas
- Actividades para niños

¡Ven y vive la tradición sensuntepecana!`,
        startDate: new Date('2024-11-24'),
        endDate: new Date('2024-12-05'),
        location: 'Centro de Sensuntepeque',
        category: 'RELIGIOSA',
        isRecurring: true,
        isPublished: true,
        organizerId: admin.id
      }
    });

    logger.info('✅ Evento de fiestas patronales creado');

    // Crear configuraciones del sitio
    const configs = [
      {
        key: 'site_name',
        value: 'Sensuntepeque Cultural',
        description: 'Nombre del sitio web'
      },
      {
        key: 'site_description',
        value: 'Portal cultural de Sensuntepeque, la ciudad de los 400 cerros. Descubre nuestra historia, tradiciones y gastronomía.',
        description: 'Descripción del sitio web'
      },
      {
        key: 'city_name',
        value: 'Sensuntepeque',
        description: 'Nombre de la ciudad'
      },
      {
        key: 'city_department',
        value: 'Cabañas',
        description: 'Departamento donde se ubica la ciudad'
      },
      {
        key: 'city_nickname',
        value: 'La ciudad de los 400 cerros',
        description: 'Apodo de la ciudad'
      },
      {
        key: 'city_patron_saint',
        value: 'Santa Bárbara',
        description: 'Santo patrono de la ciudad'
      },
      {
        key: 'city_population',
        value: '35916',
        description: 'Población actual de la ciudad'
      },
      {
        key: 'city_altitude',
        value: '820',
        description: 'Altitud en metros sobre el nivel del mar'
      },
      {
        key: 'city_coordinates_lat',
        value: '13.876152777778',
        description: 'Latitud de la ciudad'
      },
      {
        key: 'city_coordinates_lng',
        value: '-88.628494444444',
        description: 'Longitud de la ciudad'
      }
    ];

    for (const config of configs) {
      await prisma.siteConfig.upsert({
        where: { key: config.key },
        update: { value: config.value },
        create: config
      });
    }

    logger.info(`✅ ${configs.length} configuraciones del sitio creadas`);

    logger.info('✨ Seeding completado exitosamente');
    logger.info('\n🎆 ¡Bienvenido a Sensuntepeque Cultural!');
    logger.info('🎭 La ciudad de los 400 cerros te espera');
    logger.info(`🔑 Admin: ${adminEmail} / ${adminPassword}`);

  } catch (error) {
    logger.error('❌ Error durante el seeding:', error);
    throw error;
  }
}

main()
  .catch((e) => {
    logger.error('Error en seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });