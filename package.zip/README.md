# Sensuntepeque Cultural - Aplicación Web

## 🏛️ Sobre el Proyecto

**Sensuntepeque Cultural** es una aplicación web completa dedicada a promover la rica cultura, historia y gastronomía de Sensuntepeque, El Salvador - conocida como "la ciudad de los 400 cerros".

### ✨ Características Principales

- 🏺 **Portal Cultural**: Historia desde la época precolombina hasta la actualidad
- 🍽️ **Gastronomía Local**: Platos típicos, recetas tradicionales y restaurantes
- 🎭 **Tradiciones Vivas**: Fiestas patronales, costumbres y celebraciones
- 🏔️ **Turismo**: Guías de lugares emblemáticos y miradores
- 📱 **Diseño Responsivo**: Optimizado para móviles, tablets y desktop
- 🔒 **Panel Administrativo**: Gestión de contenido segura
- 🌐 **SEO Optimizado**: Posicionamiento web avanzado

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** + **TypeScript** - Framework moderno y tipado fuerte
- **Tailwind CSS** - Diseño utilitario y responsivo
- **Framer Motion** - Animaciones suaves y atractivas
- **React Router** - Navegación SPA
- **Axios** - Cliente HTTP

### Backend
- **Node.js** + **Express** + **TypeScript** - API REST robusta
- **Prisma ORM** - Manejo de base de datos type-safe
- **JWT** + **bcrypt** - Autenticación segura
- **Multer** - Carga de archivos
- **Helmet** - Seguridad HTTP
- **CORS** - Configuración de acceso cruzado

### Base de Datos
- **PostgreSQL** - Base de datos relacional robusta
- **Redis** (opcional) - Cache de sesiones

### DevOps
- **Docker** + **Docker Compose** - Containerización
- **ESLint** + **Prettier** - Calidad de código
- **Jest** - Testing unitario

## 📋 Funcionalidades Implementadas

### 🎯 Módulos Principales

1. **Historia y Cultura**
   - Cronología desde época precolombina (fundación por Pipiles en 1550)
   - Evolución histórica hasta ciudad en 1865
   - Patrimonio arquitectónico (Iglesia Santa Bárbara, plaza central)

2. **Tradiciones Sensuntepecanas**
   - Los Fogones (7 de diciembre)
   - Las "Recordadas" (serenatas durante fiestas patronales)
   - La Corrida del Ángel (Domingo de Resurrección)
   - Alfombras de aserrín en Semana Santa

3. **Gastronomía Típica**
   - Riguas con leche cruda
   - Atol shuco
   - Pupusas y tamales
   - Café de altura de Cabañas

4. **Fiestas y Celebraciones**
   - Fiestas patronales de Santa Bárbara (24 nov - 5 dic)
   - Virgen del Tránsito (15 agosto)
   - Festivales turísticos locales

5. **Turismo y Lugares**
   - Miradores de los "400 cerros"
   - Iglesia Parroquial Santa Bárbara
   - Plaza central y kiosco
   - Rutas hacia Ilobasco (artesanías)

## 🚀 Instalación y Configuración

### Prerrequisitos
- Node.js 18+
- PostgreSQL 13+
- Git

### 1. Clonar el proyecto
```bash
git clone <repository-url>
cd sensuntepeque-cultural
```

### 2. Configurar Backend
```bash
cd backend
npm install
cp .env.example .env
# Editar .env con tus configuraciones
npm run db:setup
npm run dev
```

### 3. Configurar Frontend
```bash
cd frontend
npm install
cp .env.example .env.local
# Editar .env.local
npm run dev
```

### 4. Con Docker (Recomendado)
```bash
docker-compose up -d
```

## 🌐 URLs de Acceso

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **Admin Panel**: http://localhost:3000/admin

## 📚 Documentación de API

La API REST está documentada con Swagger en: `http://localhost:5000/api-docs`

### Endpoints Principales

```
GET    /api/historia           # Información histórica
GET    /api/tradiciones        # Tradiciones y costumbres
GET    /api/gastronomia        # Platos y recetas
GET    /api/eventos            # Fiestas y celebraciones
GET    /api/lugares            # Sitios turísticos
POST   /api/auth/login         # Autenticación
POST   /api/admin/*            # Endpoints administrativos
```

## 🧪 Testing

```bash
# Backend
cd backend && npm test

# Frontend
cd frontend && npm test

# E2E
npm run test:e2e
```

## 🚢 Despliegue

### Producción con Docker
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Vercel (Frontend)
```bash
cd frontend
npm run build
vercel --prod
```

### Railway/Heroku (Backend)
```bash
cd backend
git push railway main  # o heroku main
```

## 🔐 Seguridad

- ✅ Autenticación JWT
- ✅ Encriptación de contraseñas (bcrypt)
- ✅ Validación de inputs
- ✅ Headers de seguridad (Helmet)
- ✅ Rate limiting
- ✅ CORS configurado
- ✅ Sanitización SQL (Prisma)

## 🎨 Diseño y UX

- ✅ Mobile-first responsive
- ✅ Accesibilidad WCAG 2.1
- ✅ Animaciones suaves
- ✅ Carga optimizada de imágenes
- ✅ PWA ready
- ✅ SEO metadata

## 📈 Performance

- ✅ Code splitting
- ✅ Lazy loading
- ✅ Image optimization
- ✅ Bundle analysis
- ✅ Caching strategies

## 🤝 Contribución

1. Fork del proyecto
2. Crear feature branch (`git checkout -b feature/nueva-funcionalidad`)
3. Commit cambios (`git commit -m 'Agregar nueva funcionalidad'`)
4. Push a branch (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

## 📝 Licencia

MIT License - Ver [LICENSE](LICENSE) para más detalles.

## 👥 Equipo

**Desarrollado por:** MiniMax Agent
**Inspirado en:** La rica cultura e historia de Sensuntepeque, Cabañas, El Salvador

---

*"Más allá de los 400 cerros"* - Promoviendo la cultura sensuntepecana para el mundo.